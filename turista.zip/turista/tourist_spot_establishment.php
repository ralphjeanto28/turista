<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_tourist_spot_six.css">
</head>
<title>ESTABLISHMENTS||TOURIST SPOTS</title>
<body>
  <div class="container">
     <div class="home-left">
      <h2>Admin Portal: List of Establishments</h2>
	  <p>
	     <div class="form-container">
              <h1>ADD TOURIST SPOTS</h1>
              <form id="touristSpotForm" action="add_tourist.php" method="post" enctype="multipart/form-data">
			   <label for="photo_url">Photo URL:</label>
                 <input type="text" id="photo_url" name="photo_url" required>
                 <label for="name">Name:</label>
                 <input type="text" id="name" name="name" required>
                 <button type="submit">Add Tourist Spot</button>
              </form>
	     </div>
	 </div>
	    <div class="home-right">
		   <h2>LIST OF TOURIST SPOTS</h2>
           <div class="table-container">
		       <input type="text" id="searchInput" placeholder="Search...">
               <table id="touristSpotTable">
                  <thead>
                     <tr>
				       <th>PHOTO</th>
                       <th>NAME</th>             
					   <th>ACTIONS</th>
                     </tr>
                  </thead>
                  <tbody>
                    <?php include 'tourist_spot_display.php'; ?>
                  </tbody>
               </table>
            </div>
			<a href="list_establishments.php" class="button">BACK</a>
		</div>
    </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('touristSpotTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>