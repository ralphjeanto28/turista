<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="about_us.css">
</head>
<title>TURISTA:YOUR JOURNEY STARTS HERE!</title>
<body>
    <header>
        <h3>TURISTA ABOUT US</h3>
        <nav>
            <ul>
                <li><a href="turista_history_portal.php">HISTORY PORTAL</a></li>
                <li><a href="turista_facts_portal.php">FUN FACTS PORTAL</a></li>
                <li><a href="turista_gallery_portal.php">GALLERY PORTAL</a></li>
                <li><a href="tourism_info_portal.php">TOURISM INFORMATION PORTAL</a></li>
            </ul>
        </nav>
    </header> 
	<div class="container">
         <div class="home-left">
		    <h3>TURISTA ABOUT US</h3>
			<p>"Discover Metro Dumaguete: Where Serenity Meets Adventure, and Every Moment is a Memory Waiting to Happen!"</p>
			<p style="text-align:justify;">Welcome to Metro Dumaguete: Your Gateway to Timeless Tranquility</p>
			<p style="text-align:justify; justify-content:interword; font-size:14px; font-family:Georgia,serif;">At Metro Dumaguete, we invite you to embark on a journey where vibrant culture, breathtaking landscapes, and warm hospitality converge to create an unforgettable experience. Nestled in the heart of the Philippines, our city is a harmonious blend of old-world charm and modern allure.</p>
			<p style="text-align:left; font-weight:bold; font-size:14px; font-family:Georgia,serif;">Our Story:</p>
		    <p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Founded on the principles of community, diversity, and sustainable tourism, Metro Dumaguete is not just a destination; it's a celebration of life's simple pleasures. Our story unfolds through cobblestone streets, bustling markets, and the laughter of locals who take pride in sharing their home with you.</p>
			<p style="text-align:left; font-weight:bold; font-size:14px; font-family:Georgia,serif;">What Sets Us Apart:</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">From the coral-rich depths of Apo Island to the historic landmarks that whisper tales of centuries past, Metro Dumaguete offers a unique tapestry of experiences. Whether you seek a tranquil escape in nature, an immersion in local traditions, or the thrill of exploration, we have something to captivate every traveler's heart.</p>
			<p style="text-align:left; font-weight:bold; font-size:14px; font-family:Georgia,serif;">Our Commitment:</p>
			<p style="text-align:left; font-size:14px; font-family:Georgia,serif;">At Metro Dumaguete, we are committed to preserving the beauty that makes our city exceptional. Our initiatives focus on responsible tourism, community engagement, and a dedication to leaving a positive impact on both visitors and locals alike.
            Join us in discovering the soul of Metro Dumaguete, where every encounter is an opportunity to create memories that linger long after you've left our shores.</p>		 
		 </div>
		 <div class="home-right">
		    <iframe width="660" height="315" src="https://www.youtube.com/embed/yKd5jLBzXo0?autoplay=1&mute=1&vq=hd720"  style="padding:5px; border:5px outset #D2DE32; margin:10px 15px;" title="Valencia" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
			<hr/ style="width:95%;">
			<h3>TURISTA MOBILE AND WEB-BASED APP</h3>
			<p style="text-align:left; font-weight:bold; font-size:14px; font-family:Georgia,serif;">Turista: Your Metro Dumaguete Expedition Awaits!</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Embark on a transformative journey through the heart of Metro Dumaguete with Turista, a revolutionary mobile and web-based app designed to elevate your travel experience. More than just a guide, Turista is your digital key to unlocking the rich tapestry of history, the thrill of discovery, and the visual feast of this captivating city.</p>
			<p style="text-align:left; font-weight:bold; font-size:14px; font-family:Georgia,serif;">History Portal: Unearth the Past</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Delve into the captivating history of Metro Dumaguete through our immersive History Portal. Uncover tales of resilience, cultural heritage, and the evolution of this charming city. From historic landmarks to hidden gems, let the past come alive as you explore Dumaguete's narrative through the ages.</p>
			<p style="text-align:left;font-size:14px; font-weight:bold; font-family:Georgia,serif;">Fun Facts Portal: Engage, Learn, Amaze</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Curiosity meets enlightenment in our Fun Facts Portal! Fascinating tidbits and trivia await, providing a delightful backdrop to your journey. Learn about local customs, traditions, and quirky anecdotes that make Metro Dumaguete a place where every corner has a story to tell.</p>
			<p style="text-align:left;font-size:14px; font-weight:bold; font-family:Georgia,serif;">Gallery Portal: Visual Poetry of Dumaguete</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Immerse yourself in the visual symphony of Metro Dumaguete with our Gallery Portal. Breathtaking images capture the essence of this picturesque city, from azure coastlines to vibrant festivals. Let the visuals inspire your itinerary and ignite your wanderlust.</p>
			<p style="text-align:left;font-size:14px; font-weight:bold; font-family:Georgia,serif;">Tourism Information Portal: Your Gateway to Discovery</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Navigate Metro Dumaguete effortlessly with our Tourism Information Portal. Discover curated guides, interactive maps, and essential tips to make the most of your adventure. From must-visit attractions to local insights, Turista ensures your journey is seamless and unforgettable.</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Why Turista?</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Turista isn't just an app; it's your passport to Metro Dumaguete's soul. Whether you're a cultural enthusiast, history buff, or simply seeking adventure, Turista tailors your exploration to your interests. Download Turista today and let the stories, facts, and beauty of Metro Dumaguete unfold at your fingertips.</p>
			<p style="text-align:left;font-size:14px; font-family:Georgia,serif;">Your adventure begins now — with Turista, where every step is a discovery!</p>
		    <hr/ style="width:95%; background:black;">
			<form action="process_contact_us.php" method="post">
               <h2 style="text-align:center; color:white;">CONTACT US</h2>
               <label for="name">Name:</label>
               <input type="text" id="name" name="name" required>
               <label for="email">Email:</label>
               <input type="email" id="email" name="email" required>
               <label for="message">Message:</label>
               <textarea id="message" name="message" rows="4" required></textarea>
               <input type="submit" value="SUBMIT" style="font-weight:bold;">
            </form>
			<hr/ style="width:95%; background:black;">
     	</div>
    </div>
  
</body>
</html>