<?php

$conn = new mysqli("localhost", "root", "", "db_establishments");

$sql = "SELECT * FROM tbl_tourist";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td><img src='" . $row['photo_url'] . "' alt='Tourist Spot Image' style='max-width: 100px; max-height: 100px; display: block; margin-left: auto; margin-right: auto;'></td>
            <td style='text-align:center;'>" . $row['name'] . "</td>
            <td style='text-align:center;'><a href='tourist_delete.php?action=delete&ID={$row['ID']}'>Delete</a> | <a href='tourist_update_form.php?ID={$row['ID']}'>Update</a></td>
          </tr>";
}
$conn->close();
?>