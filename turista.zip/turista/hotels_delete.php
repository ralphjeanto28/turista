<?php
// Handle restaurant deletion
include("establishments.php");

if (isset($_GET['ID'])) {
    $id = $_GET['ID'];
    $query = "DELETE FROM tbl_hotels WHERE ID = $id";
    mysqli_query($conn, $query);

    mysqli_close($conn);
    header("Location:hotel_establishment.php");
} else {
    // Redirect to the main page if no ID is provided
    header("Location:hotel_establishment.php");
}
?>