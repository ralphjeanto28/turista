<?php
include('establishments.php');

$sql = "SELECT * FROM tbl_tourist";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
		echo "<td style='text-align:center;'><img src='" . $row['photo_url'] . "' alt='Tourist Spot Image' style='max-width:100%; max-height:100px;'></td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No Tourist Spot found</td></tr>";
}

$conn->close();
?>