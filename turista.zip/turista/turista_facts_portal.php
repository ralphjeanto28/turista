<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="facts_styles_portal.css">
</head>
<title>TURISTA:FUN FACTS PORTAL</title>
<body>
  <header>
        <h3 style="font-family:Georgia,serif; font-weight:bold;">FUN FACTS PORTAL</h3>
        <nav>
            <ul>
			    <li><a href="turista_history_portal.php">HISTORY</a></li>
                <li><a href="turista_gallery_portal.php">GALLERY</a></li>
				<li><a href="tourism_info_portal.php">TOURISM INFORMATION PORTAL</a></li>
                <li><a href="turista_about_us_portal.php">ABOUT US</a></li>
				<li><a href="turista_logout.php">LOGOUT</a></li>
            </ul>
        </nav>
    </header> 
	
	<div class="container">
         <div class="home-left">
		   <h2 style="font-family:Georgia,serif; font-weight:bold;">FUN FACTS</h2>
		   <p>Discovering the Charms of Metro Dumaguete: A Fun-Filled Expedition</p>
		   <p>Nestled along the captivating shores of Negros Oriental, the vibrant and enchanting Metro Dumaguete beckons travelers with its unique blend of natural wonders, cultural treasures, and warm hospitality. As you embark on a journey through this captivating destination, let's unravel some intriguing fun facts that add a delightful layer to the tapestry of Dumaguete's allure.</p>
		   <center><img src="/turista/admin_background/facts_photo_two.jpg" style="width:100%;"></center>
		   <p>Nestled along the shores of Negros Oriental, Metro Dumaguete beckons travelers with a unique blend of natural wonders and warm hospitality. Aptly known as the "City of Gentle People," Dumaguete is characterized by the friendly demeanor of its residents. Home to the oldest American-established university in the Philippines, Silliman University, the city boasts a rich historical tapestry. Beyond its educational prowess, Dumaguete offers marine enthusiasts a treat with dolphin and whale watching in the Bohol Sea. Just a short boat ride away, Apo Island's marine sanctuary showcases a vibrant underwater world. The iconic Rizal Boulevard, named after national hero Jose Rizal, invites leisurely strolls along the waterfront, providing a perfect setting to savor local delights and witness captivating sunsets. Culminating in the grand Buglasan Festival, Dumaguete's cultural heritage is celebrated through vibrant street dancing, beauty pageants, and a showcase of traditional arts and crafts. Join us on a journey through the heart of Metro Dumaguete, where every corner reveals the city's unique charm and charisma.</p>  
		 </div>
		 <div class="home-right">
		    <div class="slideshow-container">
                <div class="mySlides fade">
                  <img src="facts_photo_one.jpg" style="width:100%">
                </div>

                <div class="mySlides fade">
                  <img src="facts_photo_two.jpg" style="width:100%">
                </div>

                <div class="mySlides fade">
                  <img src="facts_photo_three.jpg" style="width:100%">
                </div>

                <a class="prev" onclick="plusSlides(-1)">❮</a>
                <a class="next" onclick="plusSlides(1)">❯</a>
            </div>
        <hr/>
		    <h2>FUN FACTS PORTAL</h2>
			<p>Welcome aboard the Dumaguete Metro, where fascinating facts blend seamlessly with the rhythmic hum of urban life. As we embark on this journey through the heart of Dumaguete City, let's uncover some delightful fun facts that add a touch of magic to our metropolitan experience.</p>
            <p>Did you know that Dumaguete is often referred to as the "City of Gentle People"? This endearing nickname encapsulates the warm and welcoming nature of the locals, making every encounter in the metro a chance to experience the renowned Filipino hospitality.</p>
			<p>As we traverse the bustling streets, keep an eye out for the majestic Silliman University, a beacon of education and culture. Established in 1901, it stands as the oldest American-founded university in Asia, proudly contributing to the intellectual tapestry of Dumaguete.</p>
			<p>Intriguingly, the city boasts a unique and vibrant underwater world just waiting to be explored. Dumaguete is a haven for divers and marine enthusiasts, with Apo Island, a marine sanctuary, lying just off its shores. Dive into the rich biodiversity beneath the waves and witness a kaleidoscope of marine life that has earned Dumaguete a spot among the top diving destinations in the Philippines.</p>
			<p>For a taste of local flavor, be sure to indulge in Dumaguete's distinct culinary delights. Sink your teeth into Silvanas, a delectable local treat, and discover why this sugary sensation has become a favorite souvenir for visitors. From street-side vendors to cozy cafes, the culinary scene in Dumaguete is a delightful adventure for your taste buds.</p>
			<p>So, as we navigate the dynamic landscapes of Metro Dumaguete, let these fun facts infuse your journey with a deeper appreciation for the culture, history, and charm that make this city a truly special destination. Sit back, relax, and let the magic of Dumaguete unfold before your eyes!</p>
		    <hr/>
			<div class="main">
               <h3 style="text-align:center; font-family:serif;">FUN FACTS PORTAL</h3>
               <p>Nestled in the heart of Negros Oriental, Metro Dumaguete beckons with a unique charm that captivates visitors from far and wide. Known as the "City of Gentle People," Dumaguete boasts a warm and inviting atmosphere, reflecting the friendly nature of its residents. The city is home to the prestigious Silliman University, a beacon of education and culture that has stood the test of time. As you traverse the city's streets, be prepared for the unexpected, as Dumaguete unfolds a tapestry of surprises. Whether it's the playful dolphins and majestic whales in the Bohol Sea or the vibrant marine life thriving in the waters around Apo Island, Dumaguete's natural wonders are bound to leave you in awe. From the iconic Rizal Boulevard to the grandeur of the Buglasan Festival, each corner of Dumaguete tells a story, weaving together a narrative of tradition, celebration, and the genuine hospitality that defines this remarkable destination. Join us as we unravel the fun facts that make Metro Dumaguete an unforgettable expedition into the heart of the Philippines.</p>
			   <h2 style="text-align:center">FUN FACTS GALLERY</h2>
			   <div class="gallery" id="gallery"></div>
               <div id="myModal" class="modal">
                 <span class="close" onclick="closeModal()">&times;</span>
               <div class="modal-content" id="modal-content"></div>
               </div>   
            </div>
		  </div>  
	</div>
<script>
let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

<script>
const imageUrls = [
    "https://i.ibb.co/85JkNbc/facts-eight.png",
    "https://i.ibb.co/v4k4kwx/facts-eighteen.jpg",
	"https://i.ibb.co/PxydDdr/facts-eleven.png",
	"https://i.ibb.co/LxtFRZL/facts-fifteen.jpg",
	"https://i.ibb.co/KrgPsjy/facts-fifty.jpg",
	"https://i.ibb.co/xYC6TNR/persona-five.png",
	"https://i.ibb.co/gmLB5zW/persona-four.png",
	"https://i.ibb.co/8cM6Zk2/persona-one.png",
	"https://i.ibb.co/znLSvcg/persona-three.png",
	"https://i.ibb.co/5sB3D2F/persona-two.png",
	"https://i.ibb.co/B4ZWqDb/place-eight.png",
	"https://i.ibb.co/xJYTQb3/place-eighteen.png",
	"https://i.ibb.co/2NWCZZ1/place-eleven.png",
	"https://i.ibb.co/7vnWVNw/place-fifteen.png",
	"https://i.ibb.co/J5xrps0/place-fifty.jpg",
	"https://i.ibb.co/Yd7BvMs/tradition-eight.jpg",
	"https://i.ibb.co/476b02w/tradition-eighteen.jpg",
	"https://i.ibb.co/xSrfgSR/tradition-eleven.jpg",
	"https://i.ibb.co/stxv9T5/tradition-fifteen.jpg",
	"https://i.ibb.co/sKYJ4pT/tradition-five.png"

];

// Dynamically populate the gallery
const gallery = document.getElementById('gallery');
imageUrls.forEach((imageUrl, index) => {
    const imageDiv = document.createElement('div');
    imageDiv.classList.add('image');
    imageDiv.onclick = () => openModal(index + 1);
    imageDiv.innerHTML = `<img src="${imageUrl}" alt="Image ${index + 1}">`;
    gallery.appendChild(imageDiv);
});

let currentSlideIndex;

function openModal(index) {
    currentSlideIndex = index;
    document.getElementById('myModal').style.display = 'block';
    showSlides(currentSlideIndex);
}

function closeModal() {
    document.getElementById('myModal').style.display = 'none';
}

function showSlides(index) {
    const modalContent = document.getElementById('modal-content');
    modalContent.innerHTML = `<img src="${imageUrls[index - 1]}" alt="Image ${index}">`;
}

// Close modal if user clicks outside of the image
window.onclick = function(event) {
    const modal = document.getElementById('myModal');
    if (event.target === modal) {
        closeModal();
    }
};
</script>
</body>
</html>		