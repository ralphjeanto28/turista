<?php
include('connection.php');

$sql = "SELECT * FROM turista_register";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['fname'] . "</td>";
        echo "<td>" . $row['lname'] . "</td>";
        echo "<td>" . $row['address'] . "</td>";
		echo "<td>" . $row['turista_nationality'] . "</td>";
	    echo "<td>" . $row['turista_origin'] . "</td>";
		echo "<td>" . $row['turista_sub_origin'] . "</td>";
		echo "<td>" . $row['date'] . "</td>";
		echo "<td>" . $row['age'] . "</td>";
	    echo "<td>" . $row['gender'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='9'>No tourists found</td></tr>";
}

$conn->close();
?>