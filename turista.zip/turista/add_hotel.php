<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $photo_url = $_POST['photo_url'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $contact_number = $_POST['contact_number'];
    $navigation_map_url = $_POST['navigation_map_url'];
    $dbHost = "localhost";
    $dbUser = "root";
    $dbPassword = "";
    $dbName = "db_establishments";
    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "INSERT INTO tbl_hotels (photo_url, name, address, contact_number, navigation_map_url)
            VALUES ('$photo_url', '$name', '$address', '$contact_number', '$navigation_map_url')";

    if ($conn->query($sql) === TRUE) {
        echo "Hotel registration successful!";
		echo "<td style='margin:0 5px;'><a href='hotel_establishment.php'>Back to Admin List: HOTELS</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
	
    $conn->close();
} else {
    echo "Submit";
}
?>