<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_ten_church.css">
</head>
<title>CHURCHES</title>
<body>
<div class="container">
     <div class="home-left">
      <h2>TOURISM INFORMATION PORTAL</h2>
	  <h3>CHURCH</h3>
      <p>Welcome to the spiritual heart of Metro Dumaguete, where centuries-old sanctuaries and the soothing cadence of hymns weave together to create a tapestry of religious devotion. The churches in this city not only stand as architectural marvels but also serve as revered havens for the faithful, embodying the rich cultural and religious heritage of Dumaguete.</p>
      <p>1. St. Catherine of Alexandria Cathedral: Architectural Elegance: As a symbol of Dumaguete's deep-rooted Catholicism, the St. Catherine of Alexandria Cathedral stands in timeless grace. Its intricate architecture, marked by gothic influences, beckons both the devout and curious to explore its spiritual ambiance.</p>
	  <p>2. Dumaguete Belfry: A Testament to Time: Standing adjacent to the cathedral, the Dumaguete Belfry whispers tales of a bygone era. Originally a watchtower during the Spanish colonial period, it now stands as a testament to Dumaguete's enduring history.</p>
	  <p> Our Lady of Perpetual Help Shrine (Redemptorist Church):Spiritual Solace: The Redemptorist Church, dedicated to Our Lady of Perpetual Help, welcomes worshipers with open arms. Its serene atmosphere provides a refuge for those seeking spiritual solace and reflection.</p>
	 </div>
	 <div class="home-right">
      <h2>LIST OF CHURCH</h2>
	  <div class="table-container">
        <input type="text" id="searchInput" placeholder="Search...">
        <table id="churchTable">
            <thead>
                <tr>
				    <th>Photo</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Website URL</th>
                    <th>Navigation Map URL</th>
                </tr>
            </thead>
            <tbody>
            <?php include('fetch_church.php'); ?>
            </tbody>
        </table>
      </div>
	 <p>Whether you seek a moment of quiet contemplation, a glimpse into Dumaguete's religious history, or an opportunity to participate in the vibrant religious celebrations, the churches in Metro Dumaguete invite you to partake in the spiritual journey that has shaped the city's identity for generations.</p>
	 </div>
</div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('churchTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>