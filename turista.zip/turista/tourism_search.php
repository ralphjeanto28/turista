<?php
// Connect to your database (replace the placeholders with your database details)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_turista";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page
$offset = ($page - 1) * $limit; // Offset for pagination

// Fetch data from the database with pagination
$sql = "SELECT * FROM tbl_establishments LIMIT $offset, $limit";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['ID']}</td>
                <td>{$row['category']}</td>
                <td>{$row['name']}</td>
                <td>{$row['address']}</td>
                <td>{$row['contact_number']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No results found</td></tr>";
}

// Pagination links
$sql = "SELECT COUNT(*) as total FROM tbl_establishments";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_records = $row['total'];
$total_pages = ceil($total_records / $limit);

echo "<div class='pagination'>";
for ($i = 1; $i <= $total_pages; $i++) {
    echo "<a href='?page=$i'>$i</a> ";
}
echo "</div>";

$conn->close();
?>