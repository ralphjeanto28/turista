<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN LOGIN PORTAL</title>
    <link rel="stylesheet" href="admin_portal_login_style.css">
</head>
<body>
    <div class="image-container">
        <center><img src="/turista/admin_background/photo_one.jpg" style="width:100%;"></center>
        <div class="overlay"></div>
    </div>

    <div class="content-container">     
        <div class="home-right">
            <form action="admin_login_form.php" method="post">
                <h3>ADMIN LOGIN FORM</h3>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">LOGIN</button>
				<a href="dayon_kamo.php" class="button">CANCEL</a>
            </form>
        </div>
    </div>
</body>
</html>