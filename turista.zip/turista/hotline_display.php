<?php

$conn = new mysqli("localhost", "root", "", "db_establishments");

$sql = "SELECT * FROM tbl_tourism_hub";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>" . $row['name'] . "</td>        
            <td>" . $row['contact_number'] . "</td>
            <td style='text-align: center;'><a href='hotline_delete.php?action=delete&ID={$row['ID']}'>Delete</a> | <a href='hub_update_form.php?ID={$row['ID']}'>Update</a></td>
          </tr>";
}
$conn->close();
?>