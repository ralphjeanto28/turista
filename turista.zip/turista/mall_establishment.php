<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_nine_mall_styles.css">
</head>
<title>ESTABLISHMENTS||MALLS</title>
<body>
   <div class="container">
     <div class="home-left">
      <h2>Admin Portal: List of Establishments</h2>
	   <div class="form-container">
       <h1>ADD MALLS</h1>
        <form id="mallsForm" action="add_mall.php" method="post" enctype="multipart/form-data">
        <label for="photo_url">Photo URL:</label>
        <input type="text" id="photo_url" name="photo_url" required>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required>
        <label for="contact_number">Contact Number:</label>
        <input type="tel" id="contact_number" name="contact_number" required>
        <label for="navigation_map_url">Navigation Map URL:</label>
        <input type="url" id="navigation_map_url" name="navigation_map_url" required>
        <button type="submit">Add Mall</button>
    </form>
</div>
	 </div>
	    <div class="home-right">
		   <h2>LIST OF MALLS</h2>
           <div class="table-container">
		       <input type="text" id="searchInput" placeholder="Search...">
               <table id="mallsTable">
                  <thead>
                     <tr>
				       <th>PHOTO</th>
                       <th>NAME</th>
                       <th>ADDRESS</th>
                       <th>CONTACT NUMBER</th>
                       <th>NAVIGATION MAP URL</th>
					   <th>ACTIONS</th>
                     </tr>
                  </thead>
                  <tbody>
                    <?php include 'malls_display.php'; ?>
                  </tbody>
               </table>
            </div>
			<a href="list_establishments.php" class="button">BACK</a>
		</div>
    </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('mallsTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</script>
</body>
</html>