<?php
session_start();

// Hardcoded admin credentials (for demonstration purposes)
$adminUsername = 'admin';
$adminPassword = 'admin1234';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === $adminUsername && $password === $adminPassword) {
        $_SESSION['admin'] = $username;
        header("Location:admin_dashboard.php");
        exit();
    } else {
        echo "Invalid username or password";
		header("Location:admin_login_portal.php");
    }
}
?>