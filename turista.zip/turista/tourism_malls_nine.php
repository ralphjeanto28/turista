<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_nine_malls.css">
</head>
<title>MALLS</title>
<body>
  <div class="container">
     <div class="home-left">
      <h2>TOURISM INFORMATION PORTAL</h2>
	  <h3>MALLS</h3>
      <p>Welcome to the bustling world of Metro Dumaguete, where the vibrant energy of the city converges with the convenience of modern shopping. Amidst the rich cultural tapestry and scenic landscapes, the malls in Metro Dumaguete stand as beacons of retail, entertainment, and community gathering.</p>
	  <p>These shopping destinations are more than just brick-and-mortar structures; they are vibrant hubs that encapsulate the spirit of Dumaguete City. From fashion enthusiasts seeking the latest trends to families looking for a day of leisure, the malls in Metro Dumaguete cater to a diverse range of needs and preferences.</p>
	 </div>
     <div class="home-right">
      <h2>LIST OF MALLS</h2>
	  <div class="table-container">
        <input type="text" id="searchInput" placeholder="Search...">
        <table id="mallsTable">
            <thead>
                <tr>
				    <th>Photo</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Navigation Map URL</th>
                </tr>
            </thead>
            <tbody>
            <?php include('fetch_malls.php'); ?>
            </tbody>
        </table>
      </div>
	  <p>Step into these shopping havens, and you'll find a harmonious blend of local and international brands, providing a unique shopping experience that reflects the dynamic nature of Dumaguete. The malls in Metro Dumaguete are not just places to shop; they are social spaces where people come together to connect, unwind, and create lasting memories.</p>
	  <p>Dive into a world of culinary delights as these malls house a diverse array of restaurants, cafes, and food courts, offering a gastronomic journey that mirrors the city's rich culinary heritage. Whether you crave local delicacies or international cuisines, Metro Dumaguete's malls are sure to satisfy your taste buds.</p>
	 </div>
  </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('mallsTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>


</body>
</html>