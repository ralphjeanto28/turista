<?php
session_start();

// Check if both first name and last name are set in the session
if (!isset($_SESSION['firstname']) || !isset($_SESSION['lastname'])) {
    header("location:login_tourist.php");
    exit();
}

// Display welcome message
$firstname = $_SESSION['firstname'];
$lastname = $_SESSION['lastname'];
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="home_portal_styles.css">
</head>
<title>TURISTA:YOUR JOURNEY STARTS HERE!</title>
<body>
     <header>
        <h3>TURISTA WELCOME PORTAL</h3>
        <nav>
            <ul>
			    <li><a href="turista_history_portal.php">HISTORY</a></li>
                <li><a href="turista_facts_portal.php">FUN FACTS</a></li>
                <li><a href="turista_gallery_portal.php">GALLERY</a></li>
				<li><a href="tourism_info_portal.php">TOURISM INFORMATION PORTAL</a></li>
                <li><a href="turista_about_us_portal.php">ABOUT US</a></li>
				<li><a href="turista_logout.php">LOGOUT</a></li>
            </ul>
        </nav>
    </header> 
	<div class="container">
         <div class="home-left">
			<center><img src="/turista/admin_background/photo_one.jpg" style="width:100%;"></center>
			<p>Welcome to Turista, where every journey begins with the promise of adventure, discovery, and unforgettable experiences! Embark on a captivating exploration as we invite you to discover the beauty and diversity that our world has to offer. Turista is not just a travel agency; it's your passport to a world of wonder and excitement.</p>
			<p>As you step into the realm of Turista, be prepared to indulge your wanderlust and explore the far corners of our planet. Whether you're a seasoned traveler or a first-time explorer, we are here to curate the perfect journey for you. Our commitment is to transform your travel dreams into reality, creating memories that will last a lifetime.</p>
			<p>At Turista, we understand that every traveler is unique, with distinct preferences and desires. That's why we tailor our services to cater to your individual needs, ensuring a personalized and enriching experience. From enchanting cultural odysseys to thrilling adventures in nature's playgrounds, our diverse range of packages guarantees something special for every kind of traveler.</p>
			<p>Welcome to Turista – where your journey starts, and the world becomes your playground. Let the adventure begin!</p>
		 </div>
		 
		 <div class="home-right">
		    <h4 style="font-family: Georgia, serif; text-align: center;">Hello,<span style="margin: 0 5px;"><?php echo $firstname; ?></span><?php echo $lastname; ?></h4>
		    <h4>Welcome to Turista: Your Journey Starts Here!</h4>
            <p>Embark on an extraordinary adventure with Turista, your ultimate gateway to a world of history, fun facts, breathtaking galleries, and invaluable tourism information. Whether you're a seasoned traveler or a first-time explorer, Turista is your compass to navigate the rich tapestry of destinations waiting to be discovered.</p>
		    <h3>HISTORY PORTAL</h3>
			<p>Dive into the depths of time as Turista unravels the captivating histories that shape the landscapes you'll encounter. From ancient civilizations to modern marvels, each destination has a story to tell. Let Turista be your guide as we explore the historical footprints that have left an indelible mark on the world.</p>
		    <h3>FUN FACTS PORTAL</h3>
			<p>Prepare to be amazed by the intriguing tidbits and anecdotes that make each location unique. Turista brings you a treasure trove of fun facts, adding a layer of wonder to your journey. Uncover the hidden gems, curious traditions, and surprising tales that will make your travel experience truly memorable.</p>
			<h3>GALLERY PORTAL</h3>
			<p>Immerse yourself in a visual feast through our stunning galleries. Turista showcases the beauty of each destination, providing a virtual tour that captures the essence of places you've dreamt of visiting. Let the images transport you and ignite the wanderlust within, fueling your desire to explore the world.</p>
			<h3>TOURISM INFORMATION PORTAL</h3>
			<p>Navigate your travels with confidence using Turista's comprehensive tourism information portal. Find practical details, travel tips, and must-see attractions for each destination. Whether you're planning a solo adventure, a family vacation, or a romantic getaway, Turista equips you with the knowledge to make informed decisions and create unforgettable memories.</p>
			<p>Turista is not just a travel guide; it's a companion on your journey, inspiring curiosity and fostering a deep appreciation for the diversity our world has to offer. Your adventure begins here, with Turista as your trusted ally. Bon voyage!</p> 
		 </div>		 
   </div>
</body>
</html>