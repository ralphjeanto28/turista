<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="list_nationality_origin_styles.css">
</head>
<title>ADMIN PORTAL|| INFLUX OF TOURISTS FOR NATIONALITY AND PLACE OF ORIGIN</title>
<body>
    
  <div class="video-container">
    <video autoplay muted loop>
      <source src="admin_video_influx.mp4" type="video/mp4">
    </video>
	<div class="container">
        <div class="home-left">
            <h3>TOURISTS'INFLUX DATA FOR NATIONALITY AND PLACE OF ORIGIN</h3>
			<p>Welcome to the vibrant city of Dumaguete, a captivating destination that attracts a diverse tapestry of tourists from both Filipino and foreign nationalities. Nestled in the heart of the Philippines, Metro Dumaguete is a haven of natural beauty, cultural richness, and warm hospitality that promises an unforgettable experience for every traveler.</p>
			<p>For Filipino tourists, Dumaguete serves as a delightful escape, offering a blend of serene landscapes, pristine beaches, and a rich historical heritage. From the enchanting Rizal Boulevard to the captivating beauty of Casaroro Falls, locals find solace and adventure in the various attractions scattered across the city. With its friendly atmosphere and close-knit community, Dumaguete beckons Filipinos to explore the beauty of their own backyard and celebrate the diverse tapestry of their cultural heritage.</p>
			<p>Foreign nationals, too, are drawn to the allure of Dumaguete's unique charm. Known as the "City of Gentle People," Dumaguete welcomes international visitors with open arms. Its universities, vibrant arts scene, and dynamic local markets create an environment that intrigues and captivates travelers from around the globe. The stunning marine biodiversity surrounding the city, with dive spots like Apo Island, makes it a hotspot for nature enthusiasts and adventure seekers.</p>
		</div>
        <div class="home-right">
           <div class="form-container">
		     <h3>TOURISTS' INFLUX FOR NATIONALITY</h3>
	         <div class="table-container">
               <table id="ListTouristTable" style="background-image:linear-gradient(to left,#FF9843,#6DA4AA);">
                <thead>
                   <tr>
				    <th>Nationality</th>
                    <th>Total Influx</th>
                   </tr>
                </thead>
                <tbody>
                   <?php include('fetch_nationality.php'); ?>
                 </tbody>
              </table>
	         </div>
			  <h3>TOURISTS' INFLUX FOR PLACE OF ORIGIN</h3>
			  <div class="table-container" style="overflow:scroll; overflow-x:hidden; padding:10px; width:82%; background-image:linear-gradient(to left,#FF9843,#6DA4AA);">
               <table id="ListTouristTable">
                <thead>
                   <tr>
				    <th>PLACE OF ORIGIN</th>
                    <th>SUB PLACE OF ORIGIN</th>
					<th>TOTAL</th>
                   </tr>
                </thead>
                <tbody>
                   <?php include('fetch_place_of_origin.php');?>
                 </tbody>
              </table>
	         </div>
			 
		  </div>
		</div>
    <div>
</div>	
 </body>
 </html>