<?php
include("establishments.php");

if (isset($_GET['ID'])) {
    $id = $_GET['ID'];
    $query = "DELETE FROM tbl_tourism_hub WHERE ID = $id";
    mysqli_query($conn, $query);

    mysqli_close($conn);
    header("Location:tourism_hub_establishment.php");
} else {
    header("Location:tourism_hub_establishment.php");
}
?>