<?php
// Check if the form is submitted
if (isset($_POST['update'])) {
    // Get form data
    $tourismId = $_POST['id'];
    $name = $_POST['name'];
    $contactNumber = $_POST['contact_number'];
    $conn = new mysqli("localhost", "root","", "db_establishments");

    // Update restaurant details
    $sql = "UPDATE tbl_tourism_hub SET  name = '$name', contact_number = '$contactNumber' WHERE ID = $tourismId";
    $conn->query($sql);

    // Redirect back to the index page
    header("Location: tourism_hub_establishment.php");
    exit();
}
?>