<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "db_establishments";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to get count for a specific table
function getEstablishmentCount($tableName, $establishmentType) {
    global $conn;
    $countQuery = "SELECT COUNT(*) as total FROM $tableName";
    $countResult = $conn->query($countQuery);

    if ($countResult->num_rows > 0) {
        $totalCount = $countResult->fetch_assoc()['total'];

        echo "<tr>";
        echo "<td style='text-align:left; font-family:Copperplate, Papyrus, fantasy; font-size:18px;'>$establishmentType</td>";
        echo "<td style='text-align:center; font-family:Copperplate, Papyrus, fantasy; font-size:18px;'>" . $totalCount . "</td>";
        echo "</tr>";
    } else {
        echo "<tr><td colspan='2' style='text-align:center; font-family:Georgia, serif; font-size:14px;'>No $establishmentType found.</td></tr>";
    }
}

echo "<table style='width:80%; margin:40px 70px; background-image:linear-gradient(to left, #F6D776,#6DA4AA);'>";
echo "<tr><th style='text-align:center;  font-family:Georgia, serif; font-size:12px;' colspan='2'>ESTABLISHMENTS INFLUX</th></tr>";

// Array of establishment types
$establishmentTypes = [
    "Restaurants" => "tbl_restaurants",
    "Fastfoods" => "tbl_fastfood",
    "Coffee Shops" => "tbl_coffee_shops",
	"Hotels" => "tbl_hotels",
    "Beach Resorts" => "tbl_resorts",
    "Schools" => "tbl_schools",
	"Tourist Spots" => "tbl_tourist",
    "Banks" => "tbl_banks",
    "Malls" => "tbl_malls",
	"Churches" => "tbl_churches",
    "Hospitals" => "tbl_hospital",
    "Tourism Hub Hotline" => "tbl_tourism_hub",
	
];

// Loop through each establishment type
foreach ($establishmentTypes as $type => $tableName) {
    getEstablishmentCount($tableName, $type);
}

echo "</table>";

$conn->close();
?>
