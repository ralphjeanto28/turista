<?php
include("establishments.php");

if (isset($_GET['ID'])) {
    $id = $_GET['ID'];
    $query = "DELETE FROM tbl_fastfood WHERE ID = $id";
    mysqli_query($conn, $query);

    mysqli_close($conn);
    header("Location:fastfood_establishment.php");
} else {
    header("Location:fastfood_establishment.php");
}
?>