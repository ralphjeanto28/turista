<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="hub_hotline_info_twelve.css">
</head>
<title>TOURISM HUB HOTLINE</title>
<body>
  <div class="container">
     <div class="home-left">
      <h2>TOURISM INFORMATION PORTAL</h2>
	  <h3>TOURISM INFORMATION HUB HOTLINE</h3>
      <p>Greetings to all travelers and explorers! Welcome to the Tourism Information Hub Hotlines for Metro Dumaguete, your one-stop destination for all things tourism-related in this enchanting city. Whether you're a local seeking adventure or a visitor eager to experience the beauty of Dumaguete, our hotlines are here to assist you in making the most of your journey.</p>
	  <p>In Metro Dumaguete, where the serene meets the spectacular, our Tourism Information Hub is dedicated to providing you with a wealth of knowledge about the city's attractions, cultural gems, dining hotspots, and exciting activities. Our goal is to ensure that every moment of your stay is filled with unforgettable experiences.</p>
	  <p>Feel free to dial our hotlines for real-time assistance, travel tips, and personalized recommendations. Our knowledgeable and friendly tourism experts are ready to guide you through the rich tapestry of Metro Dumaguete, helping you create a tailor-made itinerary that suits your interests and preferences.</p>
	  <p>From pristine beaches to historical landmarks, vibrant local markets to delicious culinary delights, Metro Dumaguete has something for every type of traveler. Let our hotlines be your gateway to discovering the hidden gems and the well-loved treasures that make this city a truly exceptional destination.</p>
	 </div>
	 <div class="home-right">
      <h2>LIST OF TOURISM HUB HOTLINE</h2>
	  <div class="table-container">

        <input type="text" id="searchInput" placeholder="Search...">
        <table id="tourismHubTable">
            <thead>
                <tr>
                    <th>Name</th>          
                    <th>Contact Number</th>
                </tr>
            </thead>
            <tbody>
            <?php include('fetch_tourism_hub.php'); ?>
            </tbody>
        </table>
      </div>
      <p>Embark on a journey of discovery and relaxation in Metro Dumaguete, where our Tourism Information Hub Hotlines are at your service, making your travel experience seamless, enjoyable, and filled with the magic that only Dumaguete can offer. Thank you for choosing us as your travel companion, and may your time in our city be filled with joy, exploration, and wonderful memories!</p>
	 </div>
</div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('tourismHubTable');
    tr = table.getElementsByTagName('tr');
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>