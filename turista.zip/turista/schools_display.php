<?php

$conn = new mysqli("localhost", "root", "", "db_establishments");

$sql = "SELECT * FROM tbl_schools";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td><img src='" . $row['photo_url'] . "' alt='School Image' style='max-width: 100px; max-height: 100px; display: block; margin-left: auto; margin-right: auto; '></td>
            <td>" . $row['name'] . "</td>
            <td>" . $row['address'] . "</td>
            <td>" . $row['contact_number'] . "</td>
            <td><a href='" . $row['website_url'] . "' target='_blank'>" . $row['website_url'] . "</a></td>
            <td><a href='" . $row['navigation_map_url'] . "' target='_blank'>" . $row['navigation_map_url'] . "</a></td>
            <td><a href='school_delete.php?action=delete&ID={$row['ID']}'>Delete</a> | <a href='schools_update_form.php?ID={$row['ID']}'>Update</a></td>
          </tr>";
}
$conn->close();
?>