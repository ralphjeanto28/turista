<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_two_coffee.css">
</head>
<title>COFFEE SHOPS</title>
<body>
  <div class="container">
     <div class="home-left">
      <h2>TOURISM INFORMATION PORTAL</h2>
	  <h3>COFFEE SHOPS</h3>
	  <p>Nestled in the heart of Dumaguete, a city that seamlessly blends laid-back charm with vibrant urban life, the coffee culture thrives as a testament to the city's diverse and dynamic atmosphere. This introduction sets the stage for an exciting exploration of the myriad coffee shops that adorn the streets of Metro Dumaguete.</p>
	  <p>Metro Dumaguete, known for its picturesque surroundings and warm hospitality, has become a haven for coffee enthusiasts seeking not just a caffeine fix, but a sensory journey through the rich flavors and unique atmospheres that each coffee shop offers. From the bustling avenues to the quieter corners, these establishments contribute to the cultural tapestry that defines Dumaguete's identity.</p>
	  <p>As we embark on this journey, we delve into the stories behind each coffee shop, uncovering the passion that propels the baristas to craft the perfect brew. Beyond being mere purveyors of coffee, these establishments are social hubs, creative spaces, and community pillars. The list not only provides a practical guide for locals and visitors seeking the best coffee experience but also serves as a celebration of the entrepreneurial spirit and cultural diversity that characterize Metro Dumaguete.</p>
	  <p>From traditional Filipino coffee blends to globally-inspired concoctions, each coffee shop in this list has a unique story to tell. Whether you're a devoted coffee connoisseur, a casual sipper, or someone seeking a cozy space to work or connect with friends, the coffee shops of Metro Dumaguete cater to a spectrum of tastes and preferences.</p>
	  <p>Join us in this exploration as we uncover the aromas, flavors, and personalities that define the coffee scene in Metro Dumaguete. It's not just about the coffee; it's about the people, the stories, and the vibrant tapestry that makes each coffee shop a distinctive gem in the cultural mosaic of this enchanting city. So, let's raise our cups and savor the brews that Metro Dumaguete has to offer.</p>
	 </div>
	 <div class="home-right">
      <h2>LIST OF COFFEE SHOPS</h2>
	  <div class="table-container">
        <input type="text" id="searchInput" onkeyup="filterCoffeeShops()" placeholder="Search for coffee shops...">
        <table id="coffeeShopTable">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Website URL</th>
                    <th>Navigation Map URL</th>
                </tr>
            </thead>
            <tbody>
			   <?php include('fetch_coffee_shops.php'); ?>
			</tbody>
        </table>
       </div>
	   <p>Metro Dumaguete, being a city in the Philippines, likely has a mix of local and international coffee shops. Popular international chains like Starbucks and local favorites could be present. Additionally, independent cafes with unique atmospheres and offerings may contribute to the coffee culture.</p>
	 </div>
  </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('coffeeShopTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; 
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>