<?php
include("establishments.php");

if (isset($_GET['ID'])) {
    $id = $_GET['ID'];
    $query = "DELETE FROM tbl_banks WHERE ID = $id";
    mysqli_query($conn, $query);

    mysqli_close($conn);
    header("Location:bank_establishment.php");
} else {
    header("Location:bank_establishment.php");
}
?>