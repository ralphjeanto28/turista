<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="gallery_styles.css" >
</head>
<title>TURISTA||GALLERY PORTAL</title>
<body>
 <header>
        <h2 style="font-family:Georgia,serif; font-weight:bold; padding:10px;">GALLERY PORTAL</h2>
        <nav>
            <ul>
			    <li><a href="turista_history_portal.php">HISTORY</a></li>
                <li><a href="turista_facts_portal.php">FUN FACTS</a></li>
				<li><a href="tourism_info_portal.php">TOURISM INFORMATION PORTAL</a></li>
                <li><a href="turista_about_us_portal.php">ABOUT US</a></li>
				<li><a href="turista_logout.php">LOGOUT</a></li>
            </ul>
        </nav>
 </header> 
<div class="container">
         <div class="home-left">
		   <h2 style="font-family:Georgia,serif; padding:0 10px;">GALLERY PORTAL</h2>
		   <p style="text-align:justify; font-weight:bold; font-family:Georgia,serif; font-size:14px;">"Where Creativity Takes Center Stage – Metro Dumaguete Gallery, Unveiling the Soul of Art in Every Stroke!"</p>
		   <p style="font-size:14px;">Nestled along the captivating shores of Negros Oriental, the vibrant and enchanting Metro Dumaguete beckons travelers with its unique blend of natural wonders, cultural treasures, and warm hospitality. As you embark on a journey through this captivating destination, let's unravel some intriguing fun facts that add a delightful layer to the tapestry of Dumaguete's allure.</p>
		   <iframe width="660" height="315" src="https://www.youtube.com/embed/yKd5jLBzXo0?autoplay=1&mute=1&vq=hd1080"  style="padding:5px; border:5px outset #D2DE32; margin:10px 15px;" title="Dumaguete" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
		   <p style="font-size:14px;">Nestled along the shores of Negros Oriental, Metro Dumaguete beckons travelers with a unique blend of natural wonders and warm hospitality. Aptly known as the "City of Gentle People," Dumaguete is characterized by the friendly demeanor of its residents. Home to the oldest American-established university in the Philippines, Silliman University, the city boasts a rich historical tapestry. Beyond its educational prowess, Dumaguete offers marine enthusiasts a treat with dolphin and whale watching in the Bohol Sea. Just a short boat ride away, Apo Island's marine sanctuary showcases a vibrant underwater world. The iconic Rizal Boulevard, named after national hero Jose Rizal, invites leisurely strolls along the waterfront, providing a perfect setting to savor local delights and witness captivating sunsets. Culminating in the grand Buglasan Festival, Dumaguete's cultural heritage is celebrated through vibrant street dancing, beauty pageants, and a showcase of traditional arts and crafts. Join us on a journey through the heart of Metro Dumaguete, where every corner reveals the city's unique charm and charisma.</p>  
		   <p style="font-size:14px;">Metro Dumaguete's Gallery Portal serves as a virtual gateway to the city's diverse art scene. Whether you're a local artist looking to exhibit your masterpieces or an art connoisseur seeking inspiration, our portal is designed to connect individuals through the universal language of art. From traditional paintings to contemporary sculptures, the Gallery Portal serves as a digital canvas, fostering creativity and cultural exchange.</p>
		   <p style="font-size:14px;">Explore curated collections, participate in virtual exhibitions, and engage with the artistic community. Metro Dumaguete's Gallery Portal is not just a space for static images but a dynamic hub where art comes to life. It's a celebration of creativity, talent, and the unique spirit of Dumaguete City.</p>	 
		   <iframe width="660" height="315" src="https://www.youtube.com/embed/RWTeRbiYdLM?autoplay=1&mute=1&vq=hd1080" style="padding:5px; border:5px outset #D2DE32; margin:10px 15px;" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
           <p style="font-size:14px;">Turista, your trusted travel companion, goes beyond the conventional tourism app. Seamlessly integrated with the Gallery Portal, Turista transforms into a multifaceted platform that guides you through Dumaguete's cultural landscape. From art galleries to historical landmarks, Turista curates personalized itineraries, ensuring you make the most of your visit.</p>
		   <p style="font-size:14px;">Navigate the city with ease using the interactive map feature, discover hidden gems, and immerse yourself in the local culture through immersive audio guides. Turista isn't just an app; it's a travel companion designed to enhance your exploration of Dumaguete, combining the convenience of modern technology with the charm of authentic experiences.</p>

		</div>
		 
		<div class="home-right">
		    <h3 style="font-family:Georgia,serif; text-align:center;">PHOTO GALLERY</h3>
		    <p style="text-align:justify; font-size:14px; padding:10px; font-weight:bold;">"Capturing Moments, Creating Memories – Metro Dumaguete Photo Gallery, Where Every Image Tells a Story."</p>
		    <p style="padding:10px; font-size:14px;">Welcome to Metro Dumaguete Photo Gallery, where we believe that each photograph is a window into a unique story, a frozen moment in time that speaks volumes. In a world inundated with fleeting snapshots, we take pride in curating an exceptional collection that goes beyond pixels and colors, delving into the heart of every image to reveal its narrative essence.</p>
			<p style="padding:10px; font-size:14px;">Our gallery is a haven for those who appreciate the artistry of photography, where each frame is a testament to the skill, passion, and creativity of our featured artists. From breathtaking landscapes to intimate portraits, every photograph displayed within these walls is a carefully crafted tale waiting to be explored.</p>
			<p style="padding:10px; font-size:14px;">Step into a realm where visual storytelling takes precedence, where the interplay of light and shadow, composition and emotion, weaves a tapestry that transcends the ordinary. Metro Dumaguete Photo Gallery invites you to immerse yourself in the magic of moments frozen in time, where the click of a shutter becomes a portal to emotions, experiences, and the beauty of the human spirit.</p>
			<p style="padding:10px; font-size:14px;">Whether you are a seasoned photography enthusiast or a casual observer, our gallery is a celebration of the visual narrative that surrounds us. Join us in discovering the power of a single frame to evoke nostalgia, inspire awe, or provoke contemplation. Every image on display is a testament to the art of seeing, and we invite you to witness the world through the lenses of our talented photographers.</p>
			<p style="padding:10px; font-size:14px;">At Metro Dumaguete Photo Gallery, we invite you to explore, connect, and appreciate the stories that unfold in every image. Because here, in the realm of visual storytelling, every photograph is not just a picture – it's a moment, a memory, and a story waiting to be told.</p>
			<div class="slideshow-container">
               <div class="mySlides fade">
                 <img src="\turista\gallery\photo_one.jpg" style="width:100%">
               </div>
               <div class="mySlides fade">
                 <img src="\turista\gallery\photo_two.jpg" style="width:100%">
               </div>
               <div class="mySlides fade">
                 <img src="\turista\gallery\photo_three.jpg" style="width:100%">
               </div>
			   <div class="mySlides fade">
                 <img src="\turista\gallery\photo_four.jpg" style="width:100%">
               </div>
			   <div class="mySlides fade">
                 <img src="\turista\gallery\photo_five.jpg" style="width:100%">
               </div>
			   <div class="mySlides fade">
                 <img src="\turista\gallery\photo_six.jpg" style="width:100%">
               </div>
			   <div class="mySlides fade">
                 <img src="\turista\gallery\photo_seven.jpg" style="width:100%">
               </div>
			    <div class="mySlides fade">
                 <img src="\turista\gallery\photo_eight.jpg" style="width:100%">
               </div>
               <a class="prev" onclick="plusSlides(-1)">❮</a>
               <a class="next" onclick="plusSlides(1)">❯</a>
            </div>
            <hr/ style="width:93.92%;">
			<p style="padding:10px;font-size:14px;">Immerse yourself in the vibrant colors of local festivals, feel the pulse of city life, and marvel at the architectural wonders that stand as testaments to Dumaguete's storied past. This gallery is a celebration of the unique blend of tradition and modernity that defines Metro Dumaguete, offering a glimpse into its soul through the lens of talented photographers.</p>
			<p style="padding:10px;font-size:14px;">Whether you're a resident cherishing familiar sights or a visitor eager to discover the city's secrets, Metro Dumaguete's Photo Gallery invites you to experience the magic of Dumaguete through the art of visual storytelling. So, come and witness the charm, vitality, and cultural richness that make Dumaguete an exceptional destination, one frame at a time.</p>
            <hr/ style="width:93.92%;">
            <h3 style="font-family:Georgia,serif; text-align:center;">VIDEO GALLERY</h3>
			<p style="font-size:14px;padding:10px;font-weight:bold;font-family:Georgia,serif;">"Metro Moments: Unveiling the Tapestry of Dumaguete through Our Lens!"</p>
            <p style="font-size:14px;padding:10px;">Welcome to "Metro Moments," where every frame we capture is a thread in the vibrant tapestry of Dumaguete. Join us as we unveil the beauty, culture, and stories that define this enchanting city through our lens. From the bustling streets to the serene landscapes, each moment is a brushstroke painting the portrait of Dumaguete's unique charm. Let's embark on this visual journey together, celebrating the rich tapestry of Metro Dumaguete through the artistry of our lens.</p>
            <p style="font-size:14px;padding:10px;">Step into the magic of Dumaguete with "Metro Moments: Unveiling the Tapestry of Dumaguete through Our Lens!" In every snapshot, we weave the threads of culture, nature, and community, creating a visual story that reflects the heart and soul of this extraordinary city. Join us on this exploration as we capture the essence of Dumaguete, frame by frame, and let the tapestry of Metro Moments unfold before your eyes.</p>
            <div class="gallery">
			  <div class="video-list">
			      <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/RWTeRbiYdLM" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Celebrate Dumaguete</div>
                       </div>
                  </div>
				  <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/QncQlO9gPFE?si=DnSJVaxCev24JYPN" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">MagSandurot Ta!</div>
                      </div>
				  </div>
				  <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/yo7JpeiYG78?si=vCbIu31AOIe6fX8j" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Dumaguete in 64 Seconds</div>
                      </div>
				  </div>
				  <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/HxsTlXCgavw?si=yWz_fFBYloc6kmH3" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Exploring the History of Dumaguete</div>
                      </div>
				  </div>
				   <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/isGG65vJBGk?si=iG3JZNuOgLWflp9B" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Buglasan Festival 2023 Opening: Civil Military Parade</div>
                      </div>
				  </div>
				   <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/It2hbebb9M8?si=f_6lf2HB95zbov4h" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Virtual Travel to Valencia, Negros Oriental</div>
                      </div>
				  </div>
				   <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/yKd5jLBzXo0?si=WvK6aotWzZLSko-v" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Exploring Dumaguete and Beyond: Spot.ph</div>
                      </div>
				  </div>
				  <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/HCD3eI05T2U?si=HEgc8PrdydKOjMkl" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Dumaguete City Philippines: Rizal Boulevard Walking Tour</div>
                      </div>
				  </div>
				  <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/_X25Qu4wXf0?si=mDXxadPsvEQwo9Iu" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Pantawan, Rizal Boulevard: 4k Virtual Tour Walk Around Dumaguete  </div>
                      </div>
				  </div>
				   <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/co1_3DYWa5w?si=fSQpBhUwrlWBoAee" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">A Remembrance of a Buzzing Dumaguete by Ned Solis</div>
                      </div>
				  </div>
				   <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/eUkYJ4RMxxE?si=UEc8FrVDluT-siUm" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Dug-ab Collective</div>
                      </div>
				  </div>
				  <div class="video-item">
				      <iframe width="560" height="315" src="https://www.youtube.com/embed/jm5NHPOay24?si=PU_keqLnTL0pU92H" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			          <div class="video-details">
                       <div class="video-title">Ligiron Racing in Valencia</div>
                      </div>
				  </div>
				  <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/RWTeRbiYdLM" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Celebrate Dumaguete</div>
                       </div>
                  </div>
				  <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/gD4nTPiEAeo?si=DaM0zUdm6Oeer7Q9" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Float Parade:Buglasan Festival 2023</div>
                       </div>
                  </div>
				   <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/FiTWClRQMn8?si=BZHN-SeOOIDex_aB" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Dumaguete Diversion Road</div>
                       </div>
                  </div>
				  <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/wiRaPF7Iq2I?si=3Wh4VGJ4IlDmvYAR" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Dumaguete Presidencia Museum Opening Tour</div>
                       </div>
                  </div>
				   <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/-jXZ1IqEraY?si=l2_s_AfwrmzHAJcY" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Dumaguete Then and Now!</div>
                       </div>
                  </div>
				   <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/mlKlyWq9bCU?si=bzBiozARb1LvIRHT" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Dumaguete Philippines: Where to go in Dumaguete</div>
                       </div>
                  </div>
				  <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/sa5NyLxWjx8?si=9ZfeUbPJvzBl8A7q" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Responsible Travel in Dumaguete</div>
                       </div>
                  </div>
				  <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/SB4mrWeCk1o?si=pX6jZagkhU1JO3Dv" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Welcome to the City of Everyday Enchantments</div>
                       </div>
                  </div>
				   <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/7KP7PFl7Pew?si=LcLLqmWX4mJmeBfO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Terra Cotta in Dumaguete City</div>
                       </div>
                  </div>
				  <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/LW6dAD6is_c?si=a-vANDRWaQegdYDN" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Welcome to Negros Oriental!</div>
                       </div>
                  </div>
				  <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/wAm0aURw3Gc?si=7I0OPMm-ozcMjOF7" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                         <div class="video-title">Walk Around in Quezon Park, Dumaguete City</div>
                       </div>
                  </div>
				  <div class="video-item">
				       <iframe width="560" height="315" src="https://www.youtube.com/embed/xng3fjLTOtI?si=6ESy4pOWfU56H39j" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					   <div class="video-details">
                       <div class="video-title">An aerial of Puncak Tanawan</div>
                       </div>
                  </div>
			  </div>
			</div>		
			<p style="font-size:14px;padding:10px;">Embark on a visual odyssey with "Metro Moments: Unveiling the Tapestry of Dumaguete through Our Lens!" We invite you to witness the city's essence captured in each frame – from the lively streets to the serene landscapes, embracing the colors and stories that define Dumaguete. Let our lens be your guide through this enchanting journey, unraveling the threads of culture, nature, and community. Join us in celebrating the artistry of Dumaguete through the captivating lens of Metro Moments!</p>
		</div>
</div>

<script>
let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>



</body>
</html>		