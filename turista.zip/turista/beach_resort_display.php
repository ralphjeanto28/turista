<?php

$conn = new mysqli("localhost", "root", "", "db_establishments");

$sql = "SELECT * FROM tbl_resorts";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td><img src='" . $row['photo_url'] . "' alt='Beach Resorts Image' style='max-width: 100px; max-height: 100px;'></td>
            <td>" . $row['name'] . "</td>
            <td>" . $row['address'] . "</td>
            <td>" . $row['contact_number'] . "</td>
            <td><a href='" . $row['navigation_map_url'] . "' target='_blank'>" . $row['navigation_map_url'] . "</a></td>
            <td><a href='resort_delete.php?action=delete&ID={$row['ID']}'>Delete</a> | <a href='resort_update_form.php?ID={$row['ID']}'>Update</a></td>
          </tr>";
}
$conn->close();
?>