<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location:admin_dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN DASHBOARD PORTAL</title>
    <link rel="stylesheet" href="admin_dashboard_styles_portal.css">
</head>
<body>
    <div class="overlay"></div>
    <div class="content-container">
        <div class="home-left">
             <img src="https://i.ibb.co/VJ0wZNC/admin-dashboard.png" " alt="Logo" style="width:80%; margin:-20px;">
        </div>
        <div class="home-right">
		   <h3 style="font-family:Georgia, serif; text-align:center;">Welcome <?php echo $_SESSION['admin']; ?>!</h3>
		   <h2 style="font-weight:bold; text-align:center; font-family:Georgia serif;"><span>MENU</span></h2>
		   <a href="tourist_registered.php" class="button"><span>LIST OF TOURIST REGISTERED</span></a>
		   <a href="tourist_usage_one.php" class="button"><span>TOURIST INFLUX FOR NATIONALITY AND PLACE OF ORIGIN</span></a>
		   <a href="list_establishments.php" class="button"><span>LIST OF ESTABLISHMENTS</span></a>   
		   <a href="influx_establishments.php" class="button"><span>INFLUX OF ESTABLISHMENTS</span></a> 
		   <a href="admin_logout.php" class="button"><span>LOGOUT</span></a>
        </div>
    </div>
</body>
</html>