<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_list_of_establishments_styles_portal.css">
</head>
<title>ADMIN PORTAL||LIST OF TOURISTS REGISTERED</title>
<body>

   <div class="container">
    <div class="home-left">
      <center><img src="/turista/admin_background/photo_one.jpg" style="width:100%;"></center>
	  <h3>LIST OF ESTABLISHMENTS</h3>
	  <p>This is a comprehensive list of various establishments falling under administrative purview, encompassing government bodies, educational institutions, and commercial enterprises. The compilation serves as a valuable resource for administrators, policymakers, and researchers, offering key information on each establishment's purpose, structure, and notable features. The goal is to provide a nuanced understanding of the diverse roles these establishments play in contributing to the socio-economic fabric of communities, emphasizing the importance of effective administration for their success. The list is a dynamic resource, regularly updated to reflect the evolving landscape of establishments and administrative practices.</p>
    </div>
    
<div class="home-right">
      <h2>LIST OF ESTABLISHMENTS</h2>
      <p>Welcome to the List of Establishments for Administration, a comprehensive compilation designed to provide a detailed overview of various organizations and institutions. This curated list aims to serve as a valuable resource for administrators, policymakers, and individuals seeking information about diverse establishments across different sectors.</p>
      <div class="tab">
               <button class="tablinks" onclick="openCity(event, 'resto')" id="defaultOpen" style="background-color:#FFF7D4; font-weight:bold; font-family:Georgia,serif;">RESTAURANT</button>
               <button class="tablinks" onclick="openCity(event, 'fastfood')" style="background-color:#CD8D7A; font-weight:bold; font-family:Georgia,serif;">FASTFOOD</button>
			   <button class="tablinks" onclick="openCity(event, 'coffee')" style="background-color:#994D1C; font-weight:bold; font-family:Georgia,serif;">COFFEE SHOP</button>
			   <button class="tablinks" onclick="openCity(event, 'hotel')" style="background-color:#EE7214; font-weight:bold; font-family:Georgia,serif;">HOTEL</button>
               <button class="tablinks" onclick="openCity(event, 'resort')" style="background-color:#BE3144; font-weight:bold; font-family:Georgia,serif;">BEACH RESORT</button>
			   <button class="tablinks" onclick="openCity(event, 'school')" style="background-color:#637E76; font-weight:bold; font-family:Georgia,serif;">SCHOOL</button>
               <button class="tablinks" onclick="openCity(event, 'tourist')" style="background-color:#739072; font-weight:bold; font-family:Georgia,serif;">TOURIST SPOT</button>
			   <button class="tablinks" onclick="openCity(event, 'bank')" style="background-image: linear-gradient(to right,#FF9130,#FECDA6); font-weight:bold; font-family:Georgia,serif;">BANK</button>
               <button class="tablinks" onclick="openCity(event, 'mall')" style="background-image: linear-gradient(to right,#3A4D39,#FAE7C9); font-weight:bold; font-family:Georgia,serif;">MALL</button>
			   <button class="tablinks" onclick="openCity(event, 'church')" style="background-image: linear-gradient(to right,#CE5A67,#F4BF96); font-weight:bold; font-family:Georgia,serif;">CHURCH</button>
               <button class="tablinks" onclick="openCity(event, 'hospital')"  style="background-image: linear-gradient(to right,#ED7D31,#748E63); font-weight:bold; font-family:Georgia,serif;">HOSPITAL</button>
			   <button class="tablinks" onclick="openCity(event, 'hub')"  style="background-image: linear-gradient(to right,#9A4444,#B6FFFA); font-weight:bold; font-family:Georgia,serif;">TOURISM HUB HOTLINE</button>
      </div>
	    <div id="resto" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>RESTAURANT</h3>
     		<p>Explore the diverse culinary landscape of Metro Dumaguete, located in the heart of Negros Oriental. From traditional Filipino favorites to international delights, the city offers a variety of dining experiences. Discover hidden gems, indulge in fresh seafood, and enjoy meals with picturesque views. Immerse yourself in local culture through culinary events and festivals. Whether you're a food enthusiast or a casual diner, Metro Dumaguete promises a memorable and flavorful adventure for all.</p>
            <div class="button-container">
              <a href="restaurant_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		
		<div id="fastfood" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>FASTFOOD</h3>
     		<p>Introducing fast food in Metro Dumaguete would involve catering to the diverse tastes and preferences of the local community while embodying the convenience and efficiency associated with this culinary phenomenon. As one of the vibrant and bustling cities in the Philippines, Metro Dumaguete provides an excellent setting for the introduction of fast food establishments, combining the city's dynamic atmosphere with the fast-paced lifestyle that characterizes this dining experience.</p>
            <div class="button-container">
              <a href="fastfood_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		
		<div id="coffee" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>COFFEE SHOP</h3>
     		<p>Welcome to the lively coffee culture of Metro Dumaguete, a charming blend of tradition and modernity. In this coastal city, coffee shops transcend their role as mere beverage providers, evolving into communal spaces and artistic havens. Dumaguete's coffee scene is characterized by diverse brewing techniques and locally sourced beans, showcasing the region's commitment to quality and support for local farmers. Whether you're a dedicated connoisseur or a casual coffee lover, Dumaguete's coffee shops offer a range of experiences, from cozy independent cafes to trendy modern spaces. Each cup tells a story of the city's warmth and hospitality, making every visit a delightful journey through the rich flavors of Metro Dumaguete's coffee culture.</p>
            <div class="button-container">
              <a href="coffee_shop_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		
		<div id="hotel" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>HOTEL</h3>
            <p>Experience the essence of Dumaguete at our centrally located hotel. Nestled in the heart of the metro area, our establishment offers a perfect blend of modern luxury and local charm. Enjoy well-appointed rooms, delectable dining, and personalized service. Whether you're here for business or leisure, our prime location provides easy access to key attractions. Indulge in a sanctuary of tranquility, savor exquisite cuisine, and discover the warmth of Dumaguete's hospitality. Welcome to a memorable stay where every detail is crafted to exceed your expectations.</p>
            <div class="button-container">
              <a href="hotel_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		<div id="resort" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>BEACH RESORT</h3>
            <p>Escape to paradise at our beach resort in Metro Dumaguete! Ideally situated along the pristine coastline, our resort offers a perfect blend of tropical serenity and modern comfort. Immerse yourself in luxurious accommodations, indulge in delectable seaside dining, and unwind on sun-kissed beaches. Whether you seek relaxation or adventure, our resort provides a haven of tranquility with easy access to local attractions. Experience the allure of Dumaguete in a setting where the sun, sea, and sand create an unforgettable retreat. Welcome to a beachfront paradise – welcome to our resort in Metro Dumaguete.</p>
             <div class="button-container">
              <a href="resort_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		<div id="school" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>SCHOOL</h3>
            <p>Embrace academic excellence in the vibrant city of Dumaguete! Our schools in Metro Dumaguete stand as beacons of learning, offering a nurturing environment where students can thrive intellectually and personally. Located in the heart of the metro area, our institutions are committed to providing quality education, fostering a sense of community, and preparing students for a dynamic future. With dedicated faculty, state-of-the-art facilities, and a focus on holistic development, our schools in Metro Dumaguete aim to inspire a passion for learning and equip students with the skills needed to succeed in an ever-evolving world. Welcome to a place where education transforms lives – welcome to our schools in Metro Dumaguete.</p>
            <div class="button-container">
              <a href="school_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		<div id="tourist" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>TOURIST SPOT</h3>
            <p>Discover the enchanting beauty of Metro Dumaguete's tourist spots! Nestled in this vibrant city are captivating attractions that showcase the rich cultural tapestry and natural wonders of the region. From historical landmarks to breathtaking landscapes, our tourist spots offer a diverse array of experiences. Immerse yourself in the local charm as you explore the vibrant markets, visit historical sites, and indulge in the warmth of the community. With easy accessibility and a wealth of unique experiences, Metro Dumaguete's tourist spots promise a journey filled with cultural richness and scenic delights. Welcome to a destination where every corner tells a story – welcome to Metro Dumaguete's mesmerizing tourist spots.</p>
             <div class="button-container">
              <a href="tourist_spot_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
	   </div>
		<div id="bank" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>BANK</h3>
            <p>Welcome to the financial hub of Metro Dumaguete, where our banks play a pivotal role in fostering economic growth and financial stability. Strategically located to serve the community, our banks are committed to providing comprehensive financial services with a focus on convenience and customer satisfaction. With modern facilities, cutting-edge technology, and a team of dedicated professionals, we aim to meet the diverse financial needs of individuals and businesses alike. Step into our branches and experience a seamless blend of traditional values and contemporary banking solutions. Welcome to the trusted financial partners of Metro Dumaguete – where your financial well-being is our priority.</p>
             <div class="button-container">
              <a href="bank_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		<div id="mall" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>MALL</h3>
            <p>Explore a world of shopping, dining, and entertainment in the heart of Metro Dumaguete! Our malls are vibrant hubs that offer a diverse range of retail experiences, from trendy fashion to local treasures. Conveniently located, these shopping destinations provide a one-stop haven for all your needs. Pamper your taste buds with delightful cuisine, catch the latest blockbuster, or indulge in a retail therapy spree. Our malls in Metro Dumaguete are not just shopping centers; they are lively spaces where the community gathers for memorable moments and shared experiences. Join us for a day of excitement and discovery at the bustling heart of Metro Dumaguete's retail scene. Welcome to our malls, where shopping becomes an experience.</p>
             <div class="button-container">
              <a href="mall_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		<div id="church" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>CHURCH</h3>
            <p>Step into the spiritual heart of Metro Dumaguete at our cherished church. A place of solace and reflection, our church stands as a symbol of faith and community. Nestled in the heart of the metro area, it welcomes all with open arms, offering a serene sanctuary for worship and contemplation. Rich in history and architectural beauty, our church serves as a beacon of unity, bringing people together in moments of prayer and celebration. Whether you seek spiritual nourishment or simply wish to experience the cultural heritage of the region, our church in Metro Dumaguete is a place of reverence and connection. Welcome to a sacred space where the spirit finds its home.</p>
            <div class="button-container">
              <a href="church_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		<div id="hospital" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>HOSPITAL</h3>
            <p>In the heart of Metro Dumaguete, our hospital stands as a beacon of health and healing. Dedicated to providing compassionate care and state-of-the-art medical services, we are committed to the well-being of our community. Our hospital is equipped with modern facilities, a skilled medical team, and a focus on patient-centric care. Whether you seek routine check-ups, specialized treatments, or emergency services, our hospital in Metro Dumaguete is here to ensure your health needs are met with expertise and compassion. Welcome to a place where your health is our priority, and quality care is our commitment.</p>
             <div class="button-container">
              <a href="hospital_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		<div id="hub" class="tabcontent"  style="background-color:#FFF7D4;">
            <h3>TOURISM HUB HOTLINE</h3>
            <p>Explore the wonders of Metro Dumaguete with the Tourism Information Hub Hotline at your service! As the gateway to local attractions, our hotline is your go-to resource for travel tips, event information, and personalized assistance. Whether you're a tourist seeking guidance or a local looking for the latest happenings, our dedicated team is ready to provide timely and accurate information. Dial in for a seamless experience, making your exploration of Metro Dumaguete's cultural richness and natural beauty a truly memorable journey. Welcome to the Tourism Information Hub Hotline – your key to unlocking the treasures of Metro Dumaguete.</p>
            <div class="button-container">
              <a href="tourism_hub_establishment.php" class="button" style="background-color:#FFF7D4; color:black;">VIEW</a>
            </div>
		</div>
		<p>From cozy cafes to trendy boutiques, educational institutions to recreational centers, Metro Dumaguete has something for everyone. As you navigate through this compilation, you'll discover the diverse tapestry of businesses that form the backbone of this community. Each entry provides essential details about the establishment, offering insights into its offerings, location, and contact information.</p>
		<p>Explore the unique charm of Metro Dumaguete through its businesses, and delve into the heart of a city that seamlessly blends tradition with modernity. As the city continues to grow and evolve, this directory aims to be your go-to resource for discovering the hidden gems and well-established favorites that make up the fabric of Metro Dumaguete.</p>
</div>
</div>
</div>

<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
	
</body>
</html>