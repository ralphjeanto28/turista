<?php
session_start();
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM turista_register WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // Successful login
        $user_data = mysqli_fetch_assoc($result);
        
        // Store user data in session
        $_SESSION['firstname'] = $user_data['fname'];
        $_SESSION['lastname'] = $user_data['lname'];

        header("location:turista_welcome_portal.php");
    } else {
        // Invalid login
        echo "<script type='text/javascript'>alert('Invalid login credentials');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="turista_login_styles.css">
  <title>TURISTA LOGIN PORTAL</title>
</head>
<body>
    <video autoplay muted loop id="video-bg">
      <source src="admin_video_influx.mp4" type="video/mp4">
      Your browser does not support the video tag.
    </video>
    <div class="home-left">
      <h2>TURISTA LOGIN PORTAL</h2>
	  <p>Welcome to the Turista Login Portal, your gateway to an immersive and unforgettable experience in Metro Dumaguete! This innovative platform has been designed with the modern traveler in mind, providing you with seamless access to a treasure trove of information and services that will enhance your visit to this charming city.</p>
	  <p>Metro Dumaguete, with its rich cultural tapestry, picturesque landscapes, and warm hospitality, invites you to explore its hidden gems and vibrant attractions. The Turista Login Portal serves as your digital companion, offering a personalized and efficient way to navigate the wonders of this enchanting destination.</p>
	  <p>Embark on a journey of discovery with the Turista Login Portal – your digital passport to the wonders of Metro Dumaguete. Whether you're a first-time visitor or a seasoned traveler, let this platform elevate your experience and create lasting memories in this vibrant destination. Dive into the heart of Dumaguete with Turista, where every click opens a door to adventure!</p>
      <img src="https://i.ibb.co/vxwbph4/login-logo.png" alt="login">
    </div>
    <div class="home-right">
       <h2>TURISTA LOGIN FORM</h2>
	   <form method="POST">
         <label for="username">Username:</label>
         <input type="text" name="username" required>
         <label for="password">Password:</label>
         <input type="password" name="password" required>
         <button type="submit">LOGIN</button>
       </form>
       <p>Don't have an account? <a href="turista_registration_portal.php">REGISTER</a></p>
	   <p><a href="dayon_kamo.php">CANCEL</a></p>
    </div>
</body>
</html>