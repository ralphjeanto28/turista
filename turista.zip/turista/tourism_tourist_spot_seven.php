<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_seven_tourist_spot.css">
</head>
<title>TOURIST SPOTS</title>
<body>
  <div class="container">
       <div class="home-left">
	      <h2>TOURISM INFORMATION PORTAL</h2>
		  <h3>TOURIST SPOTS</h3>
		  <p>Welcome to Metro Dumaguete, a charming destination that seamlessly blends urban vibrancy with provincial tranquility. Rizal Boulevard, a picturesque seaside promenade, sets the stage for your exploration with its palm-lined walkways and stunning sunset views. Silliman University, an academic and cultural gem, showcases colonial-era architecture and a rich heritage. Nature enthusiasts can escape to Casaroro Falls, hidden in the mountains, or indulge in the unique experience of Pulangbato Falls and Hot Springs, where a red river flows amidst lush surroundings. The Valencia Church and Forest Camp offer a delightful blend of history and adventure, while Apo Island beckons underwater enthusiasts with its vibrant marine life. The Dumaguete Cathedral stands as a testament to the city's cultural roots. With friendly locals, diverse attractions, and a laid-back atmosphere, Metro Dumaguete invites you to create unforgettable memories in the heart of the Philippines.</p>
		  <p>Discover the enchanting allure of Metro Dumaguete, a captivating destination where the rhythm of city life harmonizes with the serenity of nature. Begin your journey at the iconic Rizal Boulevard, where the sea breeze and vibrant local scene create a perfect blend of relaxation and excitement. Silliman University, steeped in history, offers a glimpse into Dumaguete's cultural and academic heritage. Nature enthusiasts can explore the hidden wonders of Casaroro Falls or immerse themselves in the contrasting beauty of Pulangbato Falls and Hot Springs. The Valencia Church and Forest Camp beckon with their unique blend of spirituality and adventure. Apo Island, just off the coast, promises underwater wonders for diving and snorkeling enthusiasts. Lastly, the Dumaguete Cathedral stands as a symbol of the city's spiritual and architectural significance. With its warm hospitality and diverse attractions, Metro Dumaguete invites you to embark on a journey where every moment becomes a cherished memory.</p>
	   </div>
	   <div class="home-right">
	        <h1>LIST OF TOURIST SPOTS</h1>
			<div class="table-container">
			   <input type="text" id="searchInput" onkeyup="filterTouristSpot()" placeholder="Search for Tourist Spots...">
               <table id="touristSpotTable">
                    <thead>
                      <tr>
                        <th>Image</th>
                        <th>Name</th>
                      </tr>
                    </thead>
                    <tbody>
					     <?php include('fetch_tourist_spots.php'); ?>
					</tbody>
               </table>
			</div>
            <p>Dumaguete's tourist spots offer a delightful mix of natural wonders, cultural experiences, and recreational activities. Whether you're an adventure seeker, nature lover, or history enthusiast, Dumaguete has something to offer for every type of traveler.</p>			
	   </div>
   </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('touristSpotTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>