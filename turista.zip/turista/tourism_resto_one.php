<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_resto.css">
</head>
<title>TOURISM INFORMATION PORTAL:RESTAURANTS</title>
<body>
  <div class="container">
     <div class="home-left">
      <h2>TOURISM INFORMATION PORTAL</h2>
	  <h3>RESTAURANTS</h3>
      <p>Welcome to the ultimate guide for culinary exploration in Metro Dumaguete – your gateway to a delectable journey through the diverse and vibrant restaurant scene in this charming city. Nestled in the heart of the Philippines, Dumaguete is not only known for its breathtaking landscapes and warm hospitality but also for its rich and diverse culinary offerings.<p>
      <p>Our Tourism Information Portal is designed to be your trusted companion as you embark on a gastronomic adventure, highlighting the best restaurants that Metro Dumaguete has to offer. Whether you're a local food enthusiast or a curious traveler, our portal aims to cater to your taste buds by providing comprehensive information on a myriad of dining options, from quaint local eateries to upscale fine dining establishments.</p>
	  <p>Explore the flavors of Metro Dumaguete through our curated list of restaurants, each offering a unique blend of local and international cuisines. From the bustling streets of the city center to the serene coastal areas, our portal covers a wide range of dining experiences, ensuring there's something for everyone.</p>
	  <p>Discover hidden gems that showcase the region's culinary traditions, as well as innovative establishments pushing the boundaries of gastronomy. Whether you crave the familiar comfort of Filipino favorites or desire to experiment with exciting fusion dishes, our portal is your compass in navigating the diverse culinary landscape of Metro Dumaguete.</p>
	  <p>Beyond just restaurant listings, our portal provides valuable insights into each dining establishment, including reviews, ratings, and special features. Make informed decisions about where to dine based on the experiences of fellow food enthusiasts, ensuring that every meal becomes a memorable part of your Dumaguete adventure.</p>
	  <p>So, whether you're a local resident looking to explore new dining spots or a traveler seeking the best culinary experiences, let our Tourism Information Portal be your guide to the restaurants in Metro Dumaguete. Get ready to indulge in the flavors of this enchanting city and embark on a gastronomic journey that will leave your taste buds tingling with delight.</p>
	 </div>
     <div class="home-right">
      <h2>LIST OF RESTAURANTS</h2>
	  <div class="table-container">
		<input type="text" id="searchInput" placeholder="Search...">
        <table id="restaurantTable">
            <thead>
                <tr>
				    <th>Photo</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Website URL</th>
                    <th>Navigation Map URL</th>
                </tr>
            </thead>
            <tbody>
            <?php include('fetch_resto.php'); ?>
            </tbody>
        </table>
       </div>
	  <p>In Metro Dumaguete, you can expect a variety of dining options ranging from local eateries serving Filipino cuisine to international restaurants offering different cuisines. The city often features seafood restaurants due to its coastal location. Additionally, cafes, fast-food chains, and casual dining spots are likely to be part of the culinary landscape. Dumaguete, being a university town, might also have student-friendly eateries.</p>
	 </div>
  </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('restaurantTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>