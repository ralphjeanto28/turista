<?php
  session_start();
  include("connection.php");
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
	  $name = $_POST['name'];
	  $email  = $_POST['email'];
	  $message =$_POST['message'];
	  if (!empty($name) && !empty($name) && !is_numeric($name)) {
          $query ="INSERT INTO tbl_contact_us(name,email,message) values('$name','$email','$message')";
          mysqli_query($conn, $query);
          echo "<script type ='text/javascript'> alert('Successfully Process ')</script>";
		  header("Location:turista_about_us_portal.php");
      } else {
        echo "<script type ='text/javascript'> alert('Please enter some valid information')</script>";
      }
	}
?>