<?php

class TouristReport {
    private $conn;

    public function __construct() {
        // Connect to your database
        $host = 'localhost';
        $username = 'root';
        $password = '';
        $database = 'db_turista';

        $this->conn = new mysqli($host, $username, $password, $database);

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function processTouristData($selectedMonth, $selectedYear) {
        $startDate = "$selectedYear-$selectedMonth-01";
        $endDate = date('Y-m-t', strtotime($startDate));

        $query = "SELECT COUNT(*) AS totalTourists,
                         SUM(CASE WHEN nationality = 'Filipino' THEN 1 ELSE 0 END) AS filipino,
                         SUM(CASE WHEN nationality = 'Foreign' THEN 1 ELSE 0 END) AS foreign
                  FROM tbl_turista_register
                  WHERE date BETWEEN '$startDate' AND '$endDate'";

        $result = $this->conn->query($query);

        if ($result) {
            $data = $result->fetch_assoc();
            return $data;
        } else {
            die("Query failed: " . $this->conn->error);
        }
    }

    public function closeConnection() {
        $this->conn->close();
    }
}

$selectedMonth = isset($_GET['month']) ? $_GET['month'] : date('m');
$selectedYear = isset($_GET['year']) ? $_GET['year'] : date('Y');


$reportGenerator = new TouristReport();

$data = $reportGenerator->processTouristData($selectedMonth, $selectedYear);


echo json_encode($data);


$reportGenerator->closeConnection();

?>