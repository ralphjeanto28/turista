<?php
// Connect to the database (replace these values with your actual database credentials)
$host = "localhost";
$username = "root";
$password = "";
$database = "db_turista";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch nationality data from the database
$query = "SELECT turista_nationality, COUNT(*) as total_influx_tourists FROM turista_register GROUP BY turista_nationality";
$result = $conn->query($query);

// Display the table rows
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['turista_nationality'] . "</td>";
        echo "<td>" . $row['total_influx_tourists'] . "</td>";
        echo "</tr>";

        // Store the totals in variables for further use
        if ($row['turista_nationality'] === 'Filipino') {
            $filipinoTotal = $row['total'];
        } elseif ($row['turista_nationality'] === 'Foreign') {
            $foreignTotal = $row['total'];
        }
    }  
} 

// Close the database connection
$conn->close();
?>