<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_eight_bank.css">
</head>
<title>BANKS</title>
<body>
   <div class="container">
     <div class="home-left">
      <h2>TOURISM INFORMATION PORTAL</h2>
	  <h3>BANKS</h3>
      <p>Metro Dumaguete is home to a diverse and dynamic banking sector that plays a crucial role in the economic landscape of this vibrant city in the Philippines. The financial institutions in Metro Dumaguete encompass a range of local and international banks, catering to the diverse financial needs of the community. From providing traditional banking services such as savings and loans to embracing digital innovations, these banks contribute significantly to the region's economic development. With a commitment to financial inclusion and customer satisfaction, Dumaguete's banks serve as pillars supporting the local businesses and individuals, fostering growth and stability in this picturesque city. This introduction merely scratches the surface of the robust financial infrastructure that defines Metro Dumaguete's banking sector.</p>
	  <p>In the heart of Metro Dumaguete, the banking landscape reflects a blend of tradition and modernity, mirroring the city's rich cultural tapestry. From prominent local banks to branches of well-known international financial institutions, these establishments contribute to the economic vibrancy of Dumaguete. With a commitment to financial accessibility and innovation, banks in the area offer an array of services, ranging from conventional savings and loans to cutting-edge digital banking solutions. As Dumaguete continues to evolve as a hub for commerce and tourism, the banking sector remains a key player, facilitating economic growth and providing residents and businesses with the financial tools needed to thrive in this dynamic city.</p>
	 </div>
     <div class="home-right">
      <h2>LIST OF BANKS</h2>
	  <div class="table-container">
        <input type="text" id="searchInput" placeholder="Search...">
        <table id="banksTable">
            <thead>
                <tr>
				    <th>Photo</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Website URL</th>
                    <th>Navigation Map URL</th>
                </tr>
            </thead>
            <tbody>
            <?php include('fetch_banks.php'); ?>
            </tbody>
        </table>
      </div>
	  <p>In Metro Dumaguete, the banking sector stands as a cornerstone of economic stability and growth. Local and international banks alike form a robust financial network, serving the diverse needs of the community. These institutions provide a spectrum of financial services, including traditional banking, investment solutions, and digital platforms, reflecting the evolving nature of the financial landscape. As Dumaguete embraces technological advancements, the banks in the region are at the forefront of offering innovative and convenient services to both residents and businesses. This interplay of tradition and modernity underscores the pivotal role that banks play in shaping the economic landscape of Metro Dumaguete.</p>
	 </div>
  </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('banksTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>