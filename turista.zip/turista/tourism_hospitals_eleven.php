<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_eleven_hospital.css">
</head>
<title>HOSPITALS</title>
<body>
 <div class="container">
     <div class="home-left">
      <h2>TOURISM INFORMATION PORTAL</h2>
	  <h3>HOSPITALS</h3>
      <p>Welcome to the heart of healthcare excellence in Metro Dumaguete, where compassion meets cutting-edge medical expertise. The city takes pride in its commitment to providing top-notch healthcare services, with hospitals that stand as pillars of wellness and healing. From modern facilities to dedicated medical professionals, the hospitals in Metro Dumaguete are at the forefront of ensuring the well-being of the community and its visitors.</p>
	  <p>In the bustling landscape of Metro Dumaguete, our hospitals proudly take center stage as beacons of hope and wellness. With a commitment to fostering a healthier community, we strive to exceed expectations in medical expertise, state-of-the-art facilities, and compassionate patient-centered care.</p>
	  <p>Our skilled and dedicated healthcare professionals, from world-class doctors and nurses to support staff, form a cohesive team working tirelessly to ensure the well-being of every patient. We embrace a holistic approach to healthcare, integrating advanced medical technologies with the warmth of human touch.</p>
	  <p>As we navigate the ever-evolving landscape of medicine, our hospitals in Metro Dumaguete continue to evolve and adapt, staying at the forefront of innovation. We prioritize patient safety, comfort, and satisfaction, providing an environment where healing can flourish.</p>
	 </div>
	 <div class="home-right">
      <h2>LIST OF HOSPITALS</h2>
	  <div class="table-container">
        <input type="text" id="searchInput" placeholder="Search...">
        <table id="hospitalTable">
            <thead>
                <tr>
				    <th>Photo</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Website URL</th>
                    <th>Navigation Map URL</th>
                </tr>
            </thead>
            <tbody>
            <?php include('fetch_hospital.php'); ?>
            </tbody>
        </table>
      </div>
	  <p>Whether it's emergency services, routine check-ups, or specialized medical treatments, the hospitals in Metro Dumaguete are steadfast in their mission to promote health, healing, and a high standard of medical care. Welcome to a community where your well-being is a top priority.</p>
	 </div>
</div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('hospitalTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>