<?php
// Check if the form is submitted
if (isset($_POST['update'])) {
    // Get form data
    $touristId = $_POST['id'];
    $photoUrl = $_POST['photo_url'];
    $name = $_POST['name'];


    // Connect to the database (replace these with your actual database details)
    $conn = new mysqli("localhost", "root","", "db_establishments");

    // Update restaurant details
    $sql = "UPDATE tbl_tourist SET photo_url = '$photoUrl', name = '$name' WHERE ID = $touristId";
    $conn->query($sql);

    // Redirect back to the index page
    header("Location: tourist_spot_establishment.php");
    exit();
}
?>