<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_style_info.css">
</head>
<title>TURISTA:YOUR JOURNEY STARTS HERE!</title>
<body>
    <header>
        <h3>TOURISM INFORMATION PORTAL</h3>
        <nav>
            <ul>
			    <li><a href="turista_welcome_portal.php">HOME</a></li>
                <li><a href="turista_history_portal.php">HISTORY PORTAL</a></li>
                <li><a href="turista_facts_portal.php">FUN FACTS PORTAL</a></li>
                <li><a href="turista_gallery_portal.php">GALLERY PORTAL</a></li>
                <li><a href="turista_about_us_portal.php">ABOUT US</a></li>
            </ul>
        </nav>
    </header>
	 <div class="container">
        <div class="home-left">
            <h3>TOURISM INFORMATION PORTAL</h3>
            <p>Welcome to Metro Dumaguete, your gateway to a captivating blend of natural beauty, cultural richness, and warm hospitality! Nestled in the heart of the Philippines, Dumaguete City beckons with its pristine beaches, lush landscapes, and vibrant local culture. Immerse yourself in the sun-drenched shores along the Dumaguete Boulevard, explore hidden island gems, and experience the thrill of snorkeling against a backdrop of breathtaking sunsets.</p>
             <center><img src="/turista/admin_background/photo_one.jpg" style="width:100%; border:4px ridge #436850;"></center>
		</div>
        <div class="home-right">
		     <div class="button-container" style="border:5px ridge #D24545; overflow-y:scroll; overflow-x:hidden; height:400px; background-image:linear-gradient(to left, #FF6868, #FFBB64);">
               <a href="tourism_resto_one.php" style="background-color:transparent; border:4px ridge white;"><img src="https://i.ibb.co/qWNRQkc/resto.png" alt="resto" class="logo"><p class="custom-paragraph">RESTAURANTS</p></a>
			   <a href="tourism_coffee_shop_two.php" style="background-color:#FFBB64; border:4px ridge white;"><img src="https://i.ibb.co/p47NQZf/coffee.png" alt="coffee" class="logo"><p class="custom-paragraph">COFFEE SHOPS</p></a>
			   <a href="tourism_fastfood_three.php" style="background-color:transparent;  border:4px ridge white;"><img src="https://i.ibb.co/7NnCfGm/fastfood.png" alt="fastfood" class="logo"><p class="custom-paragraph">FASTFOODS</p></a>
			   <a href="tourism_hotels_four.php" style="background-color:#FFBB64; border:4px ridge white;"><img src="https://i.ibb.co/zVVYvGh/hotel.png" alt="hotel" class="logo"><p class="custom-paragraph">HOTELS</p></a>
			   <a href="tourism_beach_resort_five.php" style="background-color:transparent;  border:4px ridge white;"><img src="https://i.ibb.co/PhVytVY/resort.png" alt="resort" class="logo"><p class="custom-paragraph">BEACH RESORTS</p></a>
			   <a href="tourism_schools_six.php" style="background-color:#FFBB64; border:4px ridge white;"><img src="https://i.ibb.co/MgrjQ4y/school.png" alt="school" class="logo"><p class="custom-paragraph">SCHOOLS</p></a>
			   <a href="tourism_tourist_spot_seven.php" style="background-color:transparent;  border:4px ridge white;"><img src="https://i.ibb.co/QXYvrvD/tourist.png" alt="tourist" class="logo"><p class="custom-paragraph">TOURIST SPOTS</p></a>
			   <a href="tourism_banks_eight.php" style="background-color:#FFBB64; border:4px ridge white;"><img src="https://i.ibb.co/0y9B9s0/bank.png" alt="bank" class="logo"><p class="custom-paragraph">BANKS</p></a>
			   <a href="tourism_malls_nine.php" style="background-color:transparent;  border:4px ridge white;"><img src="https://i.ibb.co/ZxWRcQH/mall.png" alt="mall" class="logo"><p class="custom-paragraph">MALLS</p></a>
			   <a href="tourism_church_ten.php" style="background-color:#FFBB64; border:4px ridge white;"><img src="https://i.ibb.co/0219FjV/church.png" alt="church" class="logo"><p class="custom-paragraph">CHURCHES</p></a>
			   <a href="tourism_hospitals_eleven.php" style="background-color:transparent;  border:4px ridge white;"><img src="https://i.ibb.co/9bdZwBb/hospital.png" alt="hospital" class="logo"><p class="custom-paragraph">HOSPITALS</p></a>
			   <a href="tourism_hub_twelve.php" style="background-color:#FFBB64; border:4px ridge white;"><img src="https://i.ibb.co/GPNsMwC/hub.png" alt="hotline" class="logo"><p class="custom-paragraph">TOURISM HUB HOTLINE</p></a> 
            </div>
        </div>
    </div>	
</body>
</html>