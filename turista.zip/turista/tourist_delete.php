<?php
include("establishments.php");

if (isset($_GET['ID'])) {
    $id = $_GET['ID'];
    $query = "DELETE FROM tbl_tourist WHERE ID = $id";
    mysqli_query($conn, $query);

    mysqli_close($conn);
    header("Location:tourist_spot_establishment.php");
} else {
    header("Location:tourist_spot_establishment.php");
}
?>