<?php
// Check if the form is submitted
if (isset($_POST['update'])) {
    // Get form data
    $hospitalId = $_POST['id'];
    $photoUrl = $_POST['photo_url'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $contactNumber = $_POST['contact_number'];
    $websiteUrl = $_POST['website_url'];
    $mapUrl = $_POST['navigation_map_url'];

    // Connect to the database (replace these with your actual database details)
    $conn = new mysqli("localhost", "root","", "db_establishments");

    // Update restaurant details
    $sql = "UPDATE tbl_hospital SET photo_url = '$photoUrl', name = '$name', address = '$address', contact_number = '$contactNumber', website_url = '$websiteUrl', navigation_map_url = '$mapUrl' WHERE ID = $hospitalId";
    $conn->query($sql);

    // Redirect back to the index page
    header("Location: hospital_establishment.php");
    exit();
}
?>