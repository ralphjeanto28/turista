<?php
include('establishments.php');

$sql = "SELECT * FROM tbl_tourism_hub";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['contact_number'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No Tourism Hotline found</td></tr>";
}

$conn->close();
?>