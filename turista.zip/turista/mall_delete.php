<?php
include("establishments.php");

if (isset($_GET['ID'])) {
    $id = $_GET['ID'];
    $query = "DELETE FROM tbl_malls WHERE ID = $id";
    mysqli_query($conn, $query);

    mysqli_close($conn);
    header("Location:mall_establishment.php");
} else {
    header("Location:mall_establishment.php");
}
?>