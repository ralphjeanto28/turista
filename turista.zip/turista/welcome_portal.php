<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="welcome_tourists_styles.css">
</head>
<title>TURISTA:YOUR JOURNEY STARTS HERE!</title>
<body>  
	<div class="home">
		 <div class="home-container">
              <div class="home-left">
               <img src="https://i.ibb.co/jGTKWjP/logo-two.png" alt="turista" style="width:60%;margin:0 auto; display:block; opacity:default;">
               <p>Welcome to Metro Dumaguete, where the vibrant tapestry of Filipino culture unfolds against the backdrop of stunning landscapes and warm hospitality. As you embark on your journey through this enchanting destination, you are about to discover the heart and soul of the Philippines. This is not just a place; it's an experience waiting to be embraced, and your adventure begins right here.</p>
               <br><p>Nestled in the central part of the archipelago, Metro Dumaguete is a gateway to a world of natural wonders, rich history, and a tapestry of traditions. From the lively streets teeming with colorful markets to the serene coastal landscapes that stretch as far as the eye can see, every step you take here is a step into a unique blend of modernity and tradition.</p>
			  </div>
                <div class="home-right">
                <h2>TURISTA</h2>
                <br><p>Turista is a web-based app designed to guide you through the enchanting wonders of Metro Dumaguete. With real-time updates, interactive maps, and a personalized touch, Turista ensures a seamless travel experience. Explore historical landmarks, cultural gems, and natural beauty effortlessly. Engage with the local community through interactive features, creating a digital scrapbook of your unique journey. Join Turista for a virtual adventure where the charm of Dumaguete awaits at your fingertips. Welcome to Turista, where every click brings you closer to the heart of Metro Dumaguete.</p>
				<br><p>Turista, the innovative mobile and web-based app for Metro Dumaguete, redefines the way locals and visitors explore and experience this captivating city. Designed to be the ultimate guide, Turista offers a plethora of features to enhance your journey. From detailed information on attractions and landmarks to user-friendly interactive maps, the app ensures seamless navigation. Stay in the know with the latest events and festivals through Turista's dynamic calendar, and savor the flavors of Metro Dumaguete with a curated guide to local cuisine. The offline mode guarantees access to essential information even without an internet connection, and personalized itineraries allow you to tailor your day to your interests. Connect with the community through user-generated content, gaining valuable insights and recommendations. With Turista, embark on a journey of discovery and make the most of your time in the heart of the Philippines.</p>
				<br><div class="button-container"><a href="dayon_kamo.php" class="button">DAYON KAMO!</a></div>
              </div>
         </div>
	</div>
</body>
</html>
