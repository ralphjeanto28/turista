<?php
include('establishments.php');

$sql = "SELECT * FROM tbl_restaurants";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
		echo "<td style='text-align:center;'><img src='" . $row['photo_url'] . "' alt='Restaurant Image' style='max-width: 100px; max-height: 100px;'></td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['address'] . "</td>";
        echo "<td>" . $row['contact_number'] . "</td>";
        echo "<td><a href='" . $row['website_url'] . "' target='_blank'>" . $row['website_url'] . "</a></td>";
        echo "<td style='text-align:center;'><a href='" . $row['navigation_map_url'] . "' target='_blank'>View Map</a></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No restaurants found</td></tr>";
}

$conn->close();
?>