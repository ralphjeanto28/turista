<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and validate restaurant registration form data
    $photo_url = $_POST['photo_url'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $contact_number = $_POST['contact_number'];
    $website_url = $_POST['website_url'];
    $navigation_map_url = $_POST['navigation_map_url'];

    // Database connection
    $dbHost = "localhost";
    $dbUser = "root";
    $dbPassword = "";
    $dbName = "db_establishments";

    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to insert restaurant data into the database
    $sql = "INSERT INTO tbl_restaurants (photo_url, name, address, contact_number, website_url, navigation_map_url)
            VALUES ('$photo_url', '$name', '$address', '$contact_number', '$website_url', '$navigation_map_url')";

    if ($conn->query($sql) === TRUE) {
        echo "Restaurant registration successful!";
		echo "<td style='margin:0 5px;'><a href='restaurant_establishment.php'>Back to Admin List: Restaurants</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Submit";
}
?>