<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_four_hotels.css">
</head>
<title>HOTELS</title>
<body>
   <div class="container">
        <div class="home-left">
		  <h2>TOURISM INFORMATION PORTAL</h2>
		  <h3>HOTELS</h3>
		  <p>Welcome to the vibrant city of Dumaguete, where a world of enchanting experiences awaits you. Nestled in the heart of the Philippines, Metro Dumaguete is a captivating destination known for its rich culture, warm hospitality, and breathtaking landscapes. Whether you're a seasoned traveler or a first-time visitor, finding the perfect accommodation is essential for a memorable stay.</p>
		  <p>Our curated list of hotels in Metro Dumaguete offers a diverse range of options to suit every traveler's preferences and budget. From luxurious beachfront resorts to cozy boutique hotels, each establishment promises a unique blend of comfort and convenience. Whether you're seeking a serene retreat, a central location for exploration, or a place that captures the local charm, our list has something for everyone.</p>
		  <p>Discover the distinctive features of each hotel, including amenities, room types, and special offerings. Immerse yourself in the warmth of Filipino hospitality and indulge in the beauty of Dumaguete, where every corner tells a story and every hotel is a gateway to new adventures.</p>
		  <p>Join us on a journey through the captivating hotels of Metro Dumaguete, where the perfect blend of comfort and culture awaits your arrival. Whether you're here for business, leisure, or a bit of both, let our list guide you to a stay that exceeds your expectations in this tropical paradise.</p>
		</div>
		<div class="home-right">
		    <h1>LIST OF HOTELS</h1>
			<div class="table-container">
               <input type="text" id="searchInput" onkeyup="filterHotels()" placeholder="Search for hotels...">
               <table id="hotelTable">
                 <thead>
                     <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Contact Number</th>
                        <th>Navigation Map URL</th>
                    </tr>
                  </thead>
                  <tbody>
				     <?php include('fetch_hotels.php'); ?>
				  </tbody>
               </table>
		   </div>
		   <p>Alternatively, if you prefer the pulsating beat of the city, hotels in the heart of Dumaguete offer a perfect blend of urban convenience and local charm. Walk out of your hotel's doorstep into bustling markets, authentic eateries, and cultural hotspots. These city sanctuaries ensure you're in the midst of all the action.</p>
        </div>
	</div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('hotelTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; 
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>