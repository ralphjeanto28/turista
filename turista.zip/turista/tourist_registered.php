
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourist_registration_list_styles.css">
</head>
<title>ADMIN PORTAL||LIST OF TOURISTS REGISTERED</title>
<body>
  <div class="container">
      <div class="home-left">
	     <h3>WELCOME TO LIST OF TOURISTS</h3>
	     <p>Tourist registration is a vital component of effective tourism management, ensuring the smooth operation and regulation of tourist activities in a given destination. This process involves the systematic recording and documentation of information pertaining to individuals or groups visiting a specific area for recreational, cultural, or leisure purposes.</p>
		 <p>The primary objectives of tourist registration are manifold. Firstly, it allows authorities to monitor and control the influx of visitors, contributing to the overall safety and security of both tourists and residents. Secondly, it aids in the collection of valuable data on tourism trends, enabling policymakers to make informed decisions about infrastructure development, resource allocation, and promotional strategies.</p>
		 <p>This list of tourist registration serves as a comprehensive guide, outlining the necessary steps and requirements for tourists to comply with local regulations. It covers essential information such as registration forms, documentation needed, and contact details for relevant authorities. Adhering to these guidelines not only ensures a hassle-free experience for tourists but also fosters a sustainable and responsible approach to tourism.</p>
	  </div>
	  <div class="home-right">
	    <h2>LIST OF TOURIST</h2>
        <div class="table-container">
		 <input type="text" id="searchInput" placeholder="Search...">
         <table id="ListTouristTable">
             <thead>
                <tr>
                  <th>FIRSTNAME</th>
                  <th>LASTNAME</th>
                  <th>ADDRESS</th>
                  <th>NATIONALITY</th>
				  <th>PLACE OF ORIGIN</th>
				  <th>SUB-PLACE OF ORIGIN</th>
                  <th>BIRTHDAY</th>
                  <th>AGE</th>
                  <th>GENDER</th>
                </tr>
             </thead>
             <tbody>
                <?php include('fetch_list_tourist.php'); ?>
             </tbody>
          </table>
	    </div>
	</div>
  </div> 
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('ListTouristTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[0]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>