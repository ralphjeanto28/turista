<?php
// Connect to the database (replace these values with your actual database credentials)
$host = "localhost";
$username = "root";
$password = "";
$database = "db_turista";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch place of origin and sub-place of origin data from the database
$query = "SELECT turista_origin, turista_sub_origin, COUNT(*) as total FROM turista_register GROUP BY turista_origin, turista_sub_origin";
$result = $conn->query($query);

// Display the table rows
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['turista_origin'] . "</td>";
        echo "<td>" . $row['turista_sub_origin'] . "</td>";
        echo "<td>" . $row['total'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='3'>No place of origin data found</td></tr>";
}

// Close the database connection
$conn->close();
?>