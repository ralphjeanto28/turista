<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_list_establishments.css">
    <title>UPDATE TOURIST SPOTS</title>
</head>
<body>
    <div class="container">
        <div class="home-left">
            <h1>UPDATE FORM</h1>
			<h3>TOURIST SPOTS</h3>
			<?php
            $touristId = $_GET['ID'];
            $conn = new mysqli("localhost", "root", "", "db_establishments");
            $sql = "SELECT * FROM tbl_tourist WHERE ID = $touristId";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
            ?>
			<div class="form-container">
			 <form action="tourist_update.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
                <label for="photo_url">PHOTO:</label>
                <input type="url" name="photo_url" value="<?php echo $row['photo_url']; ?>" required>
                <label for="name">NAME:</label>
                <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
                <button type="submit" name="update">UPDATE</button>
              </form>
			</div>
			
            <?php
            } else {
                echo "Tourist Spot not found.";
            }
            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>