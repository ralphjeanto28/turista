<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="history_portal_styles.css">
</head>
<title>TURISTA:YOUR JOURNEY STARTS HERE!</title>
<body>
   <header>
        <h3>HISTORY PORTAL</h3>
        <nav>
            <ul>
			    <li><a href="turista_welcome_portal.php">HOME</a></li>
                <li><a href="turista_facts_portal.php">FUN FACTS</a></li>
                <li><a href="turista_gallery_portal.php">GALLERY</a></li>
				<li><a href="tourism_info_portal.php">TOURISM INFORMATION PORTAL</a></li>
                <li><a href="turista_about_us_portal.php">ABOUT US</a></li>
            </ul>
        </nav>
    </header>
	
  <div class="container">
    <div class="home-left">
      <h2>HISTORY OF METRO DUMAGUETE</h2>
      <p style="font-family:Georgia,serif;">Metro systems play a crucial role in the urban development of cities worldwide, providing efficient and sustainable transportation solutions for growing populations. Dumaguete, a vibrant city in the Philippines known for its universities, historical sites, and natural beauty, has also seen the evolution of its own metro system over the years.
      <br><br>The inception of the Metro Dumaguete can be traced back to the city's increasing urbanization and the need for a reliable and efficient public transportation system. The history of this metro system reflects the city's commitment to modernization and addressing the challenges of congestion and accessibility.</p>
      <iframe width="690" height="315" src="https://www.youtube.com/embed/LW6dAD6is_c?autoplay=1&mute=1" style="margin:0 5px;" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	  <p style="font-family:Georgia,serif;">Metro Dumaguete refers to the urbanized area centered around Dumaguete City, the capital of the province of Negros Oriental in the Philippines. Nestled in the Visayan region, Metro Dumaguete has grown into a vibrant and dynamic hub that blends the charm of a provincial setting with the conveniences of a modern urban environment.</p>
	  <p style="font-family:Georgia,serif;">Dumaguete City, often hailed as the "City of Gentle People," serves as the focal point of Metro Dumaguete, attracting residents and visitors alike with its picturesque landscapes, friendly atmosphere, and academic prominence. Home to prestigious institutions such as Silliman University, the city has earned a reputation as a center for education, culture, and intellectual pursuits.</p>
	  <p style="font-family:Georgia,serif;">The metro area encompasses not only Dumaguete City but also the neighboring municipalities and barangays that contribute to its economic, social, and cultural landscape. From bustling markets to serene coastal areas, Metro Dumaguete offers a diverse range of experiences, making it a destination that appeals to both locals and tourists seeking a balance between urban living and natural beauty.</p>
	  <p style="font-family:Georgia,serif;">The region is known for its rich marine biodiversity, drawing diving enthusiasts and nature lovers to explore the underwater wonders of the nearby Apo Island and other marine sanctuaries. Additionally, the presence of historical sites, local festivals, and a thriving culinary scene adds to the allure of Metro Dumaguete, creating a multifaceted destination that caters to various interests.
      As Metro Dumaguete continues to evolve, its commitment to sustainability, cultural preservation, and community development remains crucial. The collaborative efforts of its residents, local government, and businesses contribute to the region's ongoing growth and its reputation as a harmonious blend of tradition and progress.</p>
	</div>
    
    <div class="home-right">
      <h2>HISTORY</h2>
	  <p style="line-height:2; font-size:14px; font-family:Georgia,serif; text-align:justify;font-weight:bold;">"Discover the Tapestry of Time: Metro Dumaguete's Past Unveiled, Present Embraced, Future Envisioned."</p>
	  <p style="padding:10px;">Metro Dumaguete, nestled on the southeastern shores of Negros Island in the Philippines,
	  has a captivating history marked by resilience and cultural richness.</p>
	  <p style="padding:10px;">The history of Metro Dumaguete is deeply intertwined with the broader historical narrative of the Philippines. The region's roots can be traced back to pre-colonial times when indigenous communities thrived in harmony with the lush natural surroundings. The arrival of Spanish colonizers in the 16th century marked a significant turning point, as Dumaguete became part of the vast colonial tapestry woven by European powers.</p>
	  <p style="padding:10px;">Over the centuries, Dumaguete evolved as a melting pot of cultures, with influences from Spanish, American, and Asian traditions shaping its identity. The city played a crucial role in the economic and cultural exchanges that characterized the Philippines' colonial era. The architecture of some of its historic structures reflects the Spanish influence, while remnants of American colonialism are evident in various aspects of the city's development.</p>
      <div class="wrap">
        <div class="box">
            <div class="box-top">
                <img class="box-image" src="https://i.ibb.co/JxBvpjR/dumaguete-seal.png" alt="dumaguete_seal_logo">
                <div class="title-flex">
                    <h4 class="box-title">DUMAGUETE CITY</h4>
                </div>
            </div>
            <p class="description" style="font-family:serif;text-align:justify;justify-content:interword; line-height:2;font-weight:200; font-family:Georgia,serif;">"Dumaguete" was coined from the Cebuano word "dagit", which means "to snatch". The word dumaguet, meaning to swoop,
                was coined because of frequent raids by Moro pirates on this coastal community and its power to attract and keep visitors, both local and 
                foreign. In 1572, Diego Lopez Povedano indicated the place as Dananguet, but cartographer Pedro Murillo Velarde in 1734 already used present
                name of Dumaguete for the settlement.</p>
            <h4 style="font-family:serif;text-align:center;">LIST OF BARANGAY</h4>
			  <div class="list-container">
                 <ul>
                  <li>BARANGAY 1: TINAGO</li>
                  <li>BARANGAY 2: UPPER LUKE WRIGHT</li>
                  <li>BARANGAY 3: BUSINESS DISTRICT</li>
				  <li>BARANGAY 4: RIZAL BOULEVARD</li>
				  <li>BARANGAY 5: SILLIMAN AREA</li>
				  <li>BARANGAY 6: CAMBAGROY</li>
				  <li>BARANGAY 7: MANGGA</li>
				  <li>BARANGAY 8: CERVANTES EXTENSION</li>
				  <li>BAGACAY</li>
				  <li>BAJUMPANDAN</li>
				  <li>BALUGO</li>
				  <li>BANILAD</li>
				  <li>BANTAYAN</li>
				  <li>BATINGUEL</li>
				  <li>BUNAO</li>
				  <li>CADAWINONAN</li>
				  <li>CALINDAGAN</li>
				  <li>CAMANJAC</li>
				  <li>CANDAU-AY</li>
				  <li>CANTIL-E</li>
				  <li>DARO</li>
				  <li>JUNOB</li>
				  <li>LOOC</li>
				  <li>MANGNAO CANAL</li>
				  <li>MOTONG</li>
				  <li>PIAPI</li>
				  <li>PULANTUBIG</li>
				  <li>TABUC-TUBIG</li>
				  <li>TACLOBO</li>
				  <li>TALAY</li>
                 </ul>
              </div>
			  <iframe width="590" height="315" src="https://www.youtube.com/embed/RWTeRbiYdLM?autoplay=1&mute=1" style="padding:5px; border: 3px solid #F3B95F; margin:10px -4px;" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
			  <p>Dumaguete City, often referred to as the "City of Gentle People," is a charming and vibrant urban center located in the province of Negros Oriental, Philippines. Nestled on the southeastern part of Negros Island, Dumaguete is recognized for its warm hospitality, tranquil atmosphere, and a rich blend of natural beauty and cultural diversity.</p>
			  <p>As you step into Dumaguete, you are greeted by a unique mix of modernity and laid-back provincial charm. The city is renowned for being home to prestigious educational institutions, earning it the moniker "University Town." Silliman University, one of the oldest universities in the country, adds an intellectual and cultural dimension to the city.</p>
			  <p>Dumaguete is more than just an academic hub; it boasts breathtaking coastal views, pristine beaches, and captivating underwater landscapes. The city is a gateway to various natural wonders, including the famous Apo Island, a marine sanctuary that attracts divers and nature enthusiasts from around the world.</p>
        </div>
      </div>
	  
	  <div class="wrap">
        <div class="box" style="background-color:#C6CF9B;">
            <div class="box-top">
                <img class="box-image" src="https://i.ibb.co/SXPq8Zf/sibulan-seal.png" alt="sibulan_seal_logo">
                <div class="title-flex">
                    <h4 class="box-title">MUNICIPALITY OF SIBULAN</h4>
                </div>
            </div>
            <p class="description" style="font-family:serif;text-align:justify;justify-content:interword;  font-family:Georgia,serif; line-height:2; font-weight:200;">Noting the wealth of springs in this area, the Spaniards named it ‘Land of Sibuls’ which meant land of numerous springs. Influence of time, as well as elements of change, got the name of this municipality modified to Sibulan, its present name. In 1838, this town became a Parish under secular order. In 1856, the parish was occupied by a regular church priest. Then, in 1910, Sibulan had its initial set of municipal government officials once it became a municipality. This was in accordance to Act No. 82 of the Philippine Commission dated January 31, 1910. Macario Literal was the first appointed municipal mayor.</p>
            <h4 style="font-family:serif;text-align:center;">LIST OF BARANGAY</h4>
			  <div class="list-container">  
			    <ul>
				  <li>AGAN-AN</li>
				  <li>AJONG</li>
				  <li>BALUGO</li>
				  <li>BOLOC-BOLOC</li>
				  <li>CALABNUGAN</li>
				  <li>CANGMATING</li>
				  <li>ENRIQUE VILLANUEVA</li>
				  <li>LOOC</li>
				  <li>MAGATAS</li>
				  <li>MANINGCAO</li>
				  <li>MASLOG</li>
				  <li>POBLACION</li>
				  <li>SAN ANTONIO</li>
				  <li>TUBIGON</li>
				  <li>TUBTUBON</li>
				</ul>
			 </div>	
			 <iframe width="590" height="315" src="https://www.youtube.com/embed/NbX2Jp57j_s?autoplay=1&mute=1" style="padding:5px; border:5px outset #294B29; margin:10px -5px;" title="Sibulan" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
			 <p>Nestled along the northeastern coast of Negros Island in the Philippines, the municipality of Sibulan emerges as a hidden gem, offering a serene escape and a gateway to natural wonders. This coastal town, bordered by the Tanon Strait on one side and lush mountains on the other, beckons travelers with its unspoiled beauty and a tranquil ambiance that invites exploration and discovery.</p>
			 <p>Sibulan is renowned for its breathtaking landscapes, where verdant hills cascade down to meet pristine shores. The municipality's coastline boasts stunning beaches and clear waters, making it a haven for beach lovers and adventurers seeking seclusion amidst nature's splendor.</p>
			 <p>Nature enthusiasts find Sibulan a paradise for eco-adventures. The town serves as a gateway to the captivating Apo Island, a marine sanctuary teeming with diverse marine life and vibrant coral reefs. Snorkeling or diving in these waters offers a glimpse into an underwater world brimming with color and life.</p>
			 <p>Amidst its natural beauty, Sibulan cherishes its cultural heritage. The town exudes a relaxed provincial charm, allowing visitors to immerse themselves in the local way of life. Rich in history, Sibulan preserves historical landmarks like the St. Anthony de Padua Church, which stands as a testament to the town's colonial past.</p>
        </div>
      </div>
	   <div class="wrap">
        <div class="box" style="background-color:#FF9800;">
            <div class="box-top">
                <img class="box-image" src="https://i.ibb.co/GcbNRjy/bacong-seal.png" alt="bacong_seal_logo">
                <div class="title-flex">
                    <h4 class="box-title">MUNICIPALITY OF BACONG</h4>
                </div>
            </div>
            <p class="description" style="font-family:serif;text-align:justify;justify-content:interword;  font-family:Georgia,serif; line-height:2; font-weight:200;">Founded in 1801, the historical importance of Bacong is well documented: it is the birthplace of General Pantaleon Villegas, Negros Oriental’s hero and only Katipunero, whose birthday is celebrated as “Leon Kilat Celebration” every July 27. Also, Barrio Isugan was the location of a battle between the Filipino and American soldiers. Every 28th of August they also Celebrate Fiesta Saint Agustin.</p>
            <h4 style="font-family:serif;text-align:center;">LIST OF BARANGAY</h4>
			 <div class="list-container">  
			    <ul>
				   <li>BALAYAGMANOK</li>
				   <li>BANILAD</li>
				   <li>BUNTIS</li>
				   <li>BUNTOD</li>
				   <li>CALANGAG</li>
				   <li>COMBADO</li>
				   <li>DOLDOL</li>
				   <li>ISUGAN</li>
				   <li>LIPTONG</li>
				   <li>LUTAO</li>
				   <li>MAGSUHOT</li>
				   <li>MALABAGO</li>
				   <li>MAMPAS</li>
				   <li>NORTH POBLACION</li>
				   <li>SACSAC</li>
				   <li>SAN MIGUEL</li>
				   <li>SOUTH POBLACION</li>
				   <li>SULODPAN</li>
				   <li>TIMBANGA</li>
				   <li>TIMBAO</li>
				   <li>TUBOD</li>
				   <li>WEST POBLACION</li>
				</ul>
			</div>
	        <iframe width="590" height="315" src="https://www.youtube.com/embed/Y8QTqQeQfFg?autoplay=1&mute=1" style="padding:5px; border:5px outset #638889; margin:10px -5px;" title="Bacong" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
			<p>Bacong, a picturesque municipality nestled in the province of Negros Oriental, Philippines, is a place of rich history, natural beauty, and vibrant community life. Situated along the southeastern coast of Negros Island, Bacong is known for its scenic landscapes, warm hospitality, and a unique blend of rural charm and urban development.</p>
			<p>The municipality boasts a diverse tapestry of cultures and traditions, reflecting the harmonious coexistence of its residents. With a population that engages in various livelihoods, including agriculture, fishing, and small-scale industries, Bacong is a dynamic hub where traditions meet modernity.</p>
			<p>One of Bacong's notable features is its commitment to environmental sustainability. The town takes pride in its lush greenery, clean rivers, and pristine shorelines, making it an ideal destination for nature enthusiasts and eco-conscious travelers. The community actively participates in conservation efforts to preserve its natural treasures for future generations.</p>
			<p>Historically, Bacong has played a role in shaping the narrative of Negros Oriental. Its heritage sites, such as old ancestral houses and century-old structures, tell the stories of bygone eras and provide a glimpse into the municipality's past. Visitors can explore these historical landmarks to gain a deeper understanding of Bacong's cultural roots.</p>
			<p>Furthermore, Bacong is a haven for those seeking tranquility and relaxation. The town offers serene beaches and resorts, providing an escape from the hustle and bustle of city life. Whether one is looking to unwind on the sandy shores or engage in water activities, Bacong offers a tranquil retreat for all.</p>
        </div>
      </div>
	  
	   <div class="wrap">
        <div class="box" style="background-color:#CD8D7A;">
            <div class="box-top">
                <img class="box-image" src="https://i.ibb.co/9wbNNk6/valencia-seal.png" alt="bacong_seal_logo">
                <div class="title-flex">
                    <h4 class="box-title">MUNICIPALITY OF VALENCIA</h4>
                </div>
            </div>
            <p class="description" style="font-family:serif;text-align:justify;justify-content:interword;  font-family:Georgia,serif; line-height:2; font-weight:200;">The former name of the municipality was originally Ermita, meaning “a secluded place”. The town got that name due to its being a refuge from the assaults of the marauding Muslim pirates. In the year 1856, the Spanish colonizers renamed Ermita to Nueva Valencia, in honor of its parish priest from Valencia, a region in Spain. In the year 1920, it was renamed Luzuriaga in honor of Don Carlos Luzuriaga, a delegate from Negros island to the Philippine Legislature. The town was finally renamed to its name in the year 1948.</p>
            <h4 style="font-family:serif;text-align:center;">LIST OF BARANGAY</h4>
			<div class="list-container"> 
              <ul> 
                <li>APOLONG</li>
                <li>EAST BALABAG</li>
                <li>WEST BALABAG</li>
                <li>BALAYAGMANOK</li>
                <li>BALILI</li>
                <li>BALUGO</li>
                <li>BONGBONG</li>
                <li>BONG-AO</li>
                <li>CALAYUGAN</li>
                <li>CAMBUCAD</li>
                <li>DOBDOB</li>
                <li>JAWA</li>
                <li>CAIDIOCAN</li>
                <li>LIPTONG</li>
                <li>LUNGA</li>
                <li>MALABO</li>
                <li>MALAUNAY</li>
                <li>MAMPAS</li>
                <li>PALINPINON</li>
                <li>NORTH POBLACION</li>
                <li>SOUTH POBLACION</li>
                <li>PUHAGAN</li>
                <li>PULANGBATO</li>
                <li>SAGBANG</li>
              </ul>				
		    </div>	
            <iframe width="590" height="315" src="https://www.youtube.com/embed/yrMyiC0MSo0?autoplay=1&mute=1"  style="padding:5px; border:5px outset #D2DE32; margin:10px -5px;" title="Valencia" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            <p>Valencia, nestled in the heart of Negros Oriental, is a vibrant municipality that exudes a unique blend of natural beauty, rich cultural heritage, and progressive development. Located on the enchanting island of Negros in the Philippines, Valencia stands as a testament to the harmonious coexistence of tradition and modernity.</p>
            <p>Blessed with lush landscapes and captivating scenery, Valencia is a haven for nature lovers. The municipality boasts picturesque mountains, verdant rice fields, and serene rivers that paint a mesmerizing backdrop for both residents and visitors alike. The captivating beauty of Casaroro Falls and the scenic panoramic views from Mount Talinis are just a glimpse of the natural wonders that make Valencia a true gem in Negros Oriental.</p>
            <p>Beyond its natural allure, Valencia takes pride in its vibrant culture and warm hospitality. The town is home to friendly communities that cherish their cultural heritage, with festivals and events that celebrate the richness of local traditions. These cultural festivities provide a glimpse into the soul of Valencia, fostering a sense of unity and pride among its residents.</p>
            <p>In recent years, Valencia has experienced significant economic growth and development. The municipality has embraced progress while maintaining its commitment to environmental sustainability. This balance is reflected in the well-planned urban areas, modern infrastructure, and various economic opportunities that contribute to the overall prosperity of Valencia.</p>
            <p>As you explore Valencia, you will encounter a community that values its past while embracing the future. Whether you are drawn to the natural wonders, cultural festivities, or the dynamic local economy, Valencia welcomes all to experience the unique charm that sets it apart as a remarkable destination in Negros Oriental.</p>			
        </div>
       </div>
  </div>	
</body>
</html>