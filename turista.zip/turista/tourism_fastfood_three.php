<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_three_fastfood.css">
</head>
<title>FASTFOODS</title>
<body>
  <div class="container">
     <div class="home-left">
      <h2>TOURISM INFORMATION PORTAL</h2>
	  <h3>FASTFOODS</h3>
	  <p>Welcome to the bustling and flavorful world of fast food in Metro Dumaguete! Nestled in the heart of the Philippines, Dumaguete City offers a diverse array of fast-food options that cater to every palate. From savory local delicacies to international favorites, this list will guide you through the gastronomic delights waiting to be savored in this vibrant city.</p>
	  <p>Dumaguete's fast-food scene reflects the rich cultural tapestry of the region, blending traditional Filipino flavors with global influences. Whether you're craving a quick bite on the go or a casual dining experience, the city's fast-food establishments have something for everyone.</p>
	  <p>From iconic local joints to well-known international chains, this compilation captures the essence of Dumaguete's culinary landscape. Join us on a journey through the delectable offerings that define the fast-food culture in Metro Dumaguete, where each establishment tells a unique story through its flavors and atmosphere.</p>
	  <p>Get ready to embark on a culinary adventure as we explore the vibrant and diverse world of fast food in Metro Dumaguete. Let your taste buds be your guide, and discover the delicious treasures that await you in this lively city!</p>
	 </div>
	 <div class="home-right">
       <h2>LIST OF FASTFOODS</h2>
	    <div class="table-container">
          <input type="text" id="searchInput" onkeyup="filterFastFoodRestaurants()" placeholder="Search for fast food restaurants...">
          <table id="fastFoodRestaurantTable">
              <thead>
                 <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Website URL</th>
                    <th>Navigation Map URL</th>
                </tr>
              </thead>
              <tbody>
			       <?php include('fetch_fastfoods.php'); ?>
			  </tbody>
           </table>
        </div>
		<p>Metro Dumaguete boasts a diverse array of fast-food options catering to varied tastes and preferences. Among the well-loved choices are Jollibee, a Filipino staple renowned for its burgers and fried chicken, and McDonald's, globally acclaimed for its iconic menu items. For those craving Chinese-Filipino flavors, Chowking offers a selection of noodle dishes and dim sum. Greenwich stands out for its delicious pizzas and pastas, providing a unique fast-food experience. Mang Inasal, a local favorite, specializes in grilled chicken paired with unlimited rice. KFC, with its famous fried chicken, and Shakey's, known for pizza and chicken, are also prominent choices. Burger King rounds off the selection with flame-grilled burgers and classic fast-food options. To ensure the most up-to-date information, it is advisable to check local directories or online platforms for the latest offerings in Metro Dumaguete.</p>
	</div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('fastFoodRestaurantTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; 
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>