<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_six_school.css">
</head>
<title>SCHOOLS</title>
<body>
   <div class="container">
       <div class="home-left">
	      <h2>TOURISM INFORMATION PORTAL</h2>
		  <h3>SCHOOLS</h3>
		  <p>Welcome to the comprehensive list of schools in Metro Dumaguete, a vibrant and education-rich region in the Philippines. This compilation aims to provide a valuable resource for students, parents, and educators seeking information about the diverse array of educational institutions that contribute to the intellectual and cultural fabric of the area.</p>
		  <p>Metro Dumaguete boasts a dynamic and inclusive educational landscape, offering a wide range of options from preschools to higher education institutions. Whether you are searching for primary schools committed to nurturing young minds or tertiary institutions dedicated to academic excellence, this list strives to encompass the full spectrum of educational opportunities available.</p>
		  <p>In this compilation, you will find details about each school, including their mission and vision, academic programs, extracurricular activities, and any unique features that set them apart. As education plays a pivotal role in shaping the future, this list aspires to empower individuals in making informed decisions about their educational journey.</p>
		  <p>We encourage you to explore the rich tapestry of educational possibilities that Metro Dumaguete has to offer. Whether you are a student embarking on your academic adventure or a parent guiding your child's educational path, may this list serve as a valuable tool to navigate the diverse and exciting world of schools in this vibrant metropolitan area.</p>
	   </div>
	   <div class="home-right">
	        <h1>LIST OF SCHOOLS</h1>
			<div class="table-container">
			   <input type="text" id="searchInput" onkeyup="filterSchools()" placeholder="Search for schools...">
               <table id="schoolTable">
                    <thead>
                      <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Contact Number</th>
                        <th>Website URL</th>
                        <th>Navigation Map URL</th>
                      </tr>
                    </thead>
                    <tbody>
					     <?php include('fetch_school.php'); ?>
					</tbody>
               </table>
			</div>	
            <p>Whether you're a student seeking an institution for your educational journey or a parent looking for the best learning environment for your child, Dumaguete's schools provide a wealth of options. The city's commitment to education ensures that learners of all levels have access to quality and diverse learning opportunities.</p>			
	   </div>
   </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('schoolTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>