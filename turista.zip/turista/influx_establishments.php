<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="influx_nationality_styles.css">
</head>
<title>ADMIN PORTAL|| INFLUX OF TOURISTS FOR NATIONALITY</title>
<body>
    
<div class="video-container">
    <video autoplay muted loop>
      <source src="admin_video_influx.mp4" type="video/mp4">
    </video>
	<div class="container">
        <div class="home-left">
            <h2>ESTABLISHMENTS INFLUX</h2> 
            <p>Welcome to the vibrant and bustling city of Metro Dumaguete, where the pulse of progress and cultural richness converge. In the midst of this dynamic locale, a new wave of establishments is set to make waves and redefine the city's landscape. This introduction serves as a prelude to the influx of innovative and exciting ventures that are poised to shape the future of Metro Dumaguete.</p>
			<p>As the city continues to evolve and thrive, a diverse range of establishments is emerging, catering to the diverse needs and preferences of its residents and visitors. From cutting-edge technology hubs to cozy cafes, from trendy boutiques to modern fitness centers, Metro Dumaguete is witnessing a surge in entrepreneurial spirit that promises to elevate the city's profile.</p>
			<p>This influx is not merely about the physical structures that grace the city but represents a cultural and economic shift, breathing new life into the community. It is an exciting time for entrepreneurs and residents alike, as Metro Dumaguete evolves into a hub of innovation, entertainment, and lifestyle experiences.</p>
        </div>
        <div class="home-right">
                <tbody>
                   <tr>
				    <td><?php include('fetch.php'); ?></td>
                   </tr>
                </tbody>
             </div>
		   </div>
		</div>
</div>	
 </body>
 </html>