<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_list_establishments.css">
    <title>UPDATE CHURCH</title>
</head>
<body>
    <div class="container">
        <div class="home-left">
            <h1>UPDATE FORM</h1>
			<h3>CHURCH</h3>
			<?php
            // Retrieve the restaurant details based on the ID (adjust the SQL query accordingly)
            $churchId = $_GET['ID']; // Assuming you pass the ID via URL
            $conn = new mysqli("localhost", "root", "", "db_establishments");
            $sql = "SELECT * FROM tbl_churches WHERE ID = $churchId";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
            ?>
			<div class="form-container">
			 <form action="church_update.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
                <label for="photo_url">PHOTO:</label>
                <input type="url" name="photo_url" value="<?php echo $row['photo_url']; ?>" required>
                <label for="name">NAME:</label>
                <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
                <label for="address">ADDRESS:</label>
                <input type="text" name="address" value="<?php echo $row['address']; ?>" required>
                <label for="contact_number">CONTACT NUMBER:</label>
                <input type="text" name="contact_number" value="<?php echo $row['contact_number']; ?>" required>
                <label for="website_url">WEBSITE:</label>
                <input type="url" name="website_url" value="<?php echo $row['website_url']; ?>" required>
                <label for="navigation_map_url">NAVIGATION MAP URL:</label>
                <input type="url" name="navigation_map_url" value="<?php echo $row['navigation_map_url']; ?>" required>
                <button type="submit" name="update">UPDATE</button>
              </form>
			</div>
			
            <?php
            } else {
                echo "Church not found.";
            }
            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>