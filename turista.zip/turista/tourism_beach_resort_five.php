<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="tourism_info_five_resort.css">
</head>
<title>BEACH RESORTS</title>
<body>
   <div class="container">
        <div class="home-left">
		  <h2>TOURISM INFORMATION PORTAL</h2>
		  <h3>BEACH RESORTS</h3>
		  <p>Welcome to the enchanting coastal haven of Metro Dumaguete, where sun-kissed shores meet unparalleled tranquility. This curated list presents a selection of the finest beach resorts in this idyllic destination, each offering a unique blend of luxury, comfort, and natural beauty.</p>
		  <p>Metro Dumaguete, nestled in the heart of the Philippines, is renowned for its pristine beaches, crystal-clear waters, and vibrant marine life. As you embark on a journey through this list, you'll discover a range of beachfront retreats that cater to every taste and preference.</p>
		  <p>Whether you seek a secluded sanctuary for a romantic escape, a family-friendly resort with an array of activities, or a diving haven to explore the mesmerizing underwater world, Metro Dumaguete has it all. Each resort featured here is a testament to the region's commitment to hospitality, providing guests with an unforgettable experience amidst the sun-drenched landscapes and the gentle rhythm of the ocean waves.</p>
		  <p>Join us as we unveil the treasures of Metro Dumaguete's beach resorts, inviting you to indulge in the perfect blend of relaxation and adventure. Get ready to immerse yourself in the warm hospitality and breathtaking scenery that make these resorts the epitome of coastal luxury in this tropical paradise.</p>
		</div>
		<div class="home-right">
		  <h1>LIST OF BEACH RESORTS</h1>
		  <div class="table-container">
            <input type="text" id="searchInput" onkeyup="filterBeachResorts()" placeholder="Search for beach resorts...">
            <table id="beachResortTable">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Contact Number</th>
                        <th>Navigation Map URL</th>
                    </tr>
                </thead>
                <tbody>
				    <?php include('fetch_beach_resorts.php'); ?>
				</tbody>
            </table>
		  </div>
		  <p>Metro Dumaguete, nestled in the Philippines, boasts a selection of enchanting beach resorts that offer a perfect blend of tranquility and adventure. Notable options include Atmosphere Resorts & Spa, known for its luxurious accommodations and top-notch spa facilities, creating an oasis of relaxation. Bongo Bongo Divers & Dive Resort caters to water enthusiasts, providing an ideal setting for diving and other aquatic activities. Meanwhile, Liquid Dive Dumaguete captures the essence of tropical paradise with its beachfront charm and vibrant atmosphere. These resorts not only provide comfortable stays but also serve as gateways to explore the captivating coastal beauty and cultural richness of Dumaguete. For the most up-to-date information and to make reservations, it's advisable to check the official websites or contact these resorts directly.</p>
        </div>
   </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('beachResortTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[1]; 
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script>
</body>
</html>