<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $contact_number = $_POST['contact_number'];
	
    $dbHost = "localhost";
    $dbUser = "root";
    $dbPassword = "";
    $dbName = "db_establishments";

    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO tbl_tourism_hub(name,contact_number)
            VALUES ('$name', '$contact_number')";

    if ($conn->query($sql) === TRUE) {
        echo "Tourism Hub Hotline registration successful!";
		echo "<td style='margin:0 5px;'><a href='tourism_hub_establishment.php'>Back to Admin List: Tourism Hub Hotline</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    echo "Submit";
}
?>