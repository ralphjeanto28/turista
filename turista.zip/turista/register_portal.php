<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user input
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $address = $_POST["address"];
    $nationality = $_POST["nationality"];
    $place_of_origin = $_POST["place_of_origin"];
    $sub_place_of_origin = $_POST["sub_place_of_origin"];
    $birthday = $_POST["birthday"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    // Validate password match
    if ($password !== $confirm_password) {
        echo "Error: Passwords do not match.";
        exit();
    }

    // Check if username already exists
    $check_username_query = "SELECT * FROM tbl_turista_register WHERE username='$username'";
    $result = $conn->query($check_username_query);

    if ($result->num_rows > 0) {
        echo "Error: Username already exists. Please choose a different username.";
        exit();
    }

    // Example SQL query for registration with all fields
    $sql = "INSERT INTO tbl_turista_register (firstname, lastname, address, nationality, place_of_origin, sub_place_of_origin, birthday, age, gender, username, password)
            VALUES ('$firstname', '$lastname', '$address', '$nationality', '$place_of_origin', '$sub_place_of_origin', '$birthday', '$age', '$gender', '$username', '$password')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to login page after successful registration
        header("Location:turista_welcome_portal.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>