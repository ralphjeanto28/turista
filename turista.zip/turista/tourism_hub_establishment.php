<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="admin_twelve_hotline_styles.css">
</head>
<title>ESTABLISHMENTS||TOURISM INFORMATION HUB HOTLINE</title>
<body>
   <div class="container">
     <div class="home-left">
      <h2>Admin Portal: List of Establishments</h2>
		 <div class="form-container">
              <h1>ADD TOURISM INFORMATION HUB HOTLINE</h1>
              <form id="hotlineForm" action="add_hotline.php" method="post" enctype="multipart/form-data">
                <label for="name">NAME:</label>
                <input type="text" name="name" id="nameInput" required>
                <label for="contact_number">CONTACT NUMBER:</label>
                <input type="text" name="contact_number" id="contact_number" required>
                <button type="submit">Add Hotline</button>
              </form>
	     </div>
	 </div>
	    <div class="home-right">
		   <h2>LIST OF TOURISM HOTLINE HUB</h2>
           <div class="table-container">
		       <input type="text" id="searchInput" placeholder="Search...">
               <table id="tourismhubTable">
                  <thead>
                     <tr>
				       <th>NAME</th>                    
                       <th>CONTACT NUMBER</th>
                       <th>ACTIONS</th>
                     </tr>
                  </thead>
                  <tbody>
                    <?php include 'hotline_display.php'; ?>
                  </tbody>
               </table>
            </div>
			<a href="list_establishments.php" class="button">BACK</a>
		</div>
    </div>
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById('searchInput');
    filter = input.value.toUpperCase();
    table = document.getElementById('tourismhubTable');
    tr = table.getElementsByTagName('tr');

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName('td')[0]; // Change index based on the column you want to search
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
});
</script> 
</body>
</html>