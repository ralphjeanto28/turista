<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="welcome_kamo_dayon_styles.css">
</head>
<title>TURISTA:YOUR JOURNEY STARTS HERE!</title>
<body>
   
	<div class="home">
		 <div class="container">
           <div class="home-left">
             <h2>DAYON KAMO PORTAL</h2>
             <p>The Dayon Kamo Portal stands as a cutting-edge platform, fostering a symbiotic relationship between administrators and tourists in the realm of tourism management. Administrators find a dynamic suite of tools within the Admin Portal, enabling them to efficiently handle bookings, analyze visitor trends, and enhance overall tourism services. This centralized hub prioritizes resource management, communication, and security, offering administrators the means to make informed decisions and ensure a seamless tourist experience. On the other side, the Tourist Portal caters to travelers, providing a user-friendly interface for exploration, planning, and engagement. With features like interactive maps, event calendars, and easy booking options, tourists can seamlessly navigate local attractions, stay informed about events, and book accommodations or activities. The Dayon Kamo Portal is not just a technological innovation; it represents a commitment to user-centric design, sustainability, and a shared vision of creating memorable and enjoyable tourism experiences for all. Welcome to a new era in tourism management and exploration with Dayon Kamo!</p>
           </div>
           <div class="home-right">
              <h2 style="font-weight:bold; text-align:center; font-family:Georgia serif;">WELCOME MENU</h2>
		      <a href="admin_login_portal.php" class="button"><span>ADMIN USER: ADMIN LOGIN PORTAL</span></a>
			  <a href="login_tourist.php" class="button"><span>TURISTA USER: TURISTA LOGIN PORTAL</span></a>
			  <a href="welcome_portal.php" class="button"><span>CANCEL</span></a>
    		  <footer>
                <p><center><?php echo date("Y"); ?> Turista: Your Journey Start Begins!. All rights reserved.</center></p>
              </footer>     			  
           </div>
         </div>
    </div>
</body>
</html>