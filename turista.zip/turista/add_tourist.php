<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $photo_url = $_POST['photo_url'];
    $name = $_POST['name'];
    $dbHost = "localhost";
    $dbUser = "root";
    $dbPassword = "";
    $dbName = "db_establishments";

    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO tbl_tourist (photo_url, name)
            VALUES ('$photo_url', '$name')";

    if ($conn->query($sql) === TRUE) {
        echo "Tourist Spot registration successful!";
		echo "<td style='margin:0 5px;'><a href='tourist_spot_establishment.php'>Back to Admin List: Tourist Spot</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
	
    $conn->close();
} else {
    echo "Submit";
}
?>