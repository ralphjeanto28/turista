<?php
  session_start();
  include("connection.php");
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
	  $firstname = $_POST['fname'];
	  $lastname  = $_POST['lname'];
	  $address = $_POST['address'];
      $selectedNationality = $_POST["turista_nationality"];
	  $placeoforigin = $_POST['turista_origin'];
	  $subplaceoforigin= $_POST['turista_sub_origin'];
	  $birthday = $_POST['date'];
	  $age = $_POST['age'];
	  $gender = $_POST['gender'];
	  $username = $_POST['username'];
	  $password = $_POST['password'];
	  if (!empty($username) && !empty($password) && !is_numeric($username)) {
          $query ="INSERT INTO turista_register(fname,lname,address,turista_nationality,turista_origin,turista_sub_origin,date,age,gender,username,password) values('$firstname','$lastname','$address',' $selectedNationality','$placeoforigin','$subplaceoforigin','$birthday','$age','$gender','$username','$password')";
          mysqli_query($conn, $query);
          echo "<script type ='text/javascript'> alert('Successfully Register')</script>";
		  header("Location:login_tourist.php");
      } else {
        echo "<script type ='text/javascript'> alert('Please enter some valid information')</script>";
      }
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="registration_styles.css">
  <title>TURISTA REGISTRATION PORTAL</title>
</head>
<body>
    <video autoplay muted loop id="video-bg">
      <source src="admin_video_influx.mp4" type="video/mp4">
      Your browser does not support the video tag.
    </video>
    <div class="home-left">
      <h2>TURISTA REGISTRATION PORTAL</h2>
	  <p>The Turista Registration Portal marks a pivotal step forward in the tourism management strategy of Metro Dumaguete. With the surging influx of visitors to this culturally vibrant destination, the need for an efficient and streamlined registration process became apparent. This online platform offers tourists a user-friendly interface, eliminating the hassle of traditional paperwork. Through this portal, essential information is collected, including personal details and travel itineraries, contributing to effective tourism management.</p>
	  <p>The Turista Registration Portal embodies Metro Dumaguete's commitment to creating a secure, efficient, and enriching environment for all those who choose to explore its treasures.</p>
      <img src="registration_logo.png" alt="registration">
   </div>
    <div class="home-right">
       <h2>TURISTA REGISTRATION FORM</h2>
	   <form method="POST">
        <label for="firstname">First Name:</label>
        <input type="text" name="fname" required>
        <label for="lastname">Last Name:</label>
        <input type="text" name="lname" required>
        <label for="address">Address:</label>
        <input type="text" name="address"required>
        <label for="turista_nationality">Select Nationality:</label>
        <select name="turista_nationality" id="turista_nationality" required>
            <option value="Filipino">Filipino Nationality</option>
            <option value="Foreign">Foreign Nationality</option>
        </select>
		<label for="originSelect">Place of Origin:</label>
        <select id="originSelect" name="turista_origin" onchange="populateSubOrigins()">
         <option value="asia">Asia</option>
         <option value="eastasia">East Asia</option>
         <option value="southasia">South Asia</option>
		 <option value="middleeast">Middle East</option>
		 <option value="northamerica">North America</option>
		 <option value="southamerica">South America</option>
		 <option value="westerneurope">Western Europe</option>
		 <option value="northerneurope">Northern Europe</option>
		 <option value="easterneurope">Eastern Europe</option>
		 <option value="australasia">Australasia/Pacific</option>
		 <option value="africa">Africa</option>
        </select>
		<label for="subOriginSelect">Sub Place of Origin:</label>
        <select id="subOriginSelect" name="turista_sub_origin"></select>     
        <label for="birthday">Birthday:</label>
        <input type="date" name="date" required>
        <label for="age">Age:</label>
        <input type="number" name="age" required>
        <label for="gender">Gender:</label>
        <select name="gender" required>
          <option value="male">Male</option>
          <option value="female">Female</option>
		  <option value="others">Others</option>
        </select>
        <label for="username">Username:</label>
        <input type="text" name="username" required>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <button type="submit">REGISTER</button>
      </form>
      <p>Already have an account? <a href="login_tourist.php">LOGIN</a></p>
    </div>
<script>
    function populateSubOrigins() {
      var originSelect = document.getElementById('originSelect');
      var subOriginSelect = document.getElementById('subOriginSelect');
      subOriginSelect.innerHTML = '';
      var subOrigins = {
        asia: ['Brunei', 'Cambodia','Indonesia','Laos','Malaysia','Myanmar','Philippines','Singapore','Thailand','Vietnam'],
        eastasia: ['China','Hongkong','Japan','Korea','Taiwan'],
        southasia: ['Bangladesh','India','Iran','Nepal','Pakistan','Sri Lanka'],
		middleeast:['Bahrain','Egypt','Israel','Jordan','Kuwait','Saudi Arabia','United Arab Emirates'],
		northamerica:['Canada','Mexico','USA'],
		southamerica:['Argentina','Brazil','Colombia','Peru','Venezuela'],
		westerneurope:['Austria','Belgium','France','Germany','Luxembourg','Netherlands','Switzerland'],
		northerneurope:['Denmark','Finland','Ireland','Norway','Sweden','United Kingdom'],
		easterneurope:['Commonwealth of Independent States','Poland','Russia'],
		australasia:['Australia','Guam','Nauru','New Zealand','Papua New Guinea'],
		africa:['Nigeria','South Africa']
      };
      var selectedOrigin = originSelect.value;
      subOrigins[selectedOrigin].forEach(function(subOrigin) {
        var option = document.createElement('option');
        option.value = subOrigin;
        option.text = subOrigin;
        subOriginSelect.add(option);
      });
    }
</script>
</body>
</html>